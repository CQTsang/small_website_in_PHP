<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"C:\Software\AppServ\www\bigHomework/application/index\view\login\login.html";i:1594234696;}*/ ?>

<!doctype html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>login</title>
	<link rel="stylesheet" type="text/css" href="/bigHomework/public/static/css/login.css">
	<!--[if IE]>
		<script src="http://libs.baidu.com/html5shiv/3.7/html5shiv.min.js"></script>
	<![endif]-->
	<script src="/bigHomework/public/static/js/jquery-1.4.2.js"></script>
</head>
<script>
$(function(){
	
	var email=$("input[name='emailNew']").val();
	var passw1=$("input[name='passw1']").val();
	var passw2=$("input[name='passw2']").val();

	$("input[name='emailNew']").blur(function(){		
		if(!checkNull("email","email地址不能为空！")){
			$("#emailCheck").hide();
			return;
		}	
		if(!checkEmail()){
			return;
		}else{
			$("#emailCheck").show();
		}
	});
	
	$("input[name='passw1']").blur(function(){	
		if(!checkNull("passw1","密码不能为空！")){
			return;
		}	
		if(!checkPassword("passw1","两次密码输入不一致")){
			return;
		}
	});

	$("input[name='passw2']").blur(function(){
		
		if(!checkNull("passw2","确认密码不能为空！")){
			return;
		}	
		if(!checkPassword("passw2","两次密码输入不一致")){
			return;
		}
	});
});

//非空验证
function checkNull(name,msg){
	var value = $("input[name='"+name+"']").val();
	$("#"+name+"_msg").text("");
	if(value==""){
		$("#"+name+"_msg").text(msg);
		$("#"+name+"_msg").css("color","red");
		return false;
	}
	return true;
}
//两次密码一致验证
function checkPassword(name,msg){
	var passw1 = $("input[name='passw1']").val();
	var passw2 = $("input[name='passw2']").val();
	$("#"+name+"_msg").text("");
	if(passw1!="" && passw2!="" && passw1!=passw2){
		$("#"+name+"_msg").text(msg);
		$("#"+name+"_msg").css("color","red");
		return false
	}
	return true;
	
}

//检查Email格式
function checkEmail(){
	var email = $("input[name='emailNew']").val();
	$("#emailCheck").show();
	if(email!=""){
		var  regExp=/^\w+@\w+(\.\w+)+$/;
		if(!regExp.test(email)){
			
			$("#email_msg").text("邮箱格式不对");
			$("#email_msg").css("color","red");
			return false;
		}
	}
	return true;
}



//检查email地址是否被注册
	function CheckEmailExit(thisobj){
	var email=$("input[name='emailNew']").val();
	$.get("<?php echo url('Register/checkEmail'); ?>",{"email":email},function($result){
		alert($result);
	});
}
</script>    
<body>
<form action="<?php echo url('Login/dologin'); ?>" method="post" name=f>
	<div class="jq22-container" style="padding-top:100px">
		<div class="login-wrap">
			<div class="login-html">
				<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>
				<input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>
				<div class="login-form">
					<div class="sign-in-htm">
						<div class="group">
							<label for="user" class="label">邮箱</label>
							<input id="user" type="text" class="input" name="email" value="a@qq.com">
						</div>
						<div class="group">
							<label for="pass" class="label">密码</label>
							<input id="pass" type="password" class="input" data-type="password" name="passw">
						</div>
						<div class="group">
							<label for="verify" class="label">验证码</label>
						<input class="input" type="text" id="code_input" value="" placeholder="请输入验证码"autocomplete=“off”/>
						</div>
								<div id="v_container" style="width: 200px;height: 50px;"></div>
						<div class="group">
							<input id="check" type="checkbox" class="check" checked>
							<label for="check"><span class="icon"></span>保存密码</label>
						</div>
						<div class="group">
							<input type="submit" class="button" value="登录" name="s"  id="my_button">
						</div>
						<div class="hr"></div>
						<div class="foot-lnk">
							<a href="#forgot">Forgot Password?</a>
						</div>
					</div>
</form>
<form action="<?php echo url('register/doRegister'); ?>" method="post" n="f">
					<div class="sign-up-htm">
						<div class="group">
							<label for="user" class="label">用户名</label>
							<input id="user" type="text" class="input" name="nameNew">
						</div>
						<div class="group">
							<label for="pass" class="label">密码</label>
							<input id="pass" type="password" class="input" data-type="password" name="passw1">
							<span id="passw1_msg"></span>
						</div>
						<div class="group">
							<label for="pass" class="label">再次输入密码</label>
							<input id="pass" type="password" class="input" data-type="password" name="passw2">
							<span id="passw2_msg"></span>
						</div>
						<div class="group">
							<label for="pass" class="label">电子邮箱</label>
							<input id="pass" type="text" class="input" name="emailNew">
							<td align=left><a id="emailCheck" href="javascript:void(0)" onclick='CheckEmailExit(this)'>检查email是否已被使用</a>
							<span id="email_msg"></span>
						</div>
						
						<div class="group">
							<input type="submit" class="button" value="注册">
						</div>
						<div class="hr"></div>
						<div class="foot-lnk">
							<label for="tab-1">Already Member?</a>
						</div>
					</div>
</form>
				</div>
			</div>
		</div>
	</div>
	
</body>
<script src="/bigHomework/public/static/js/gVerify.js"></script>
	<script>
		var verifyCode = new GVerify("v_container");

		document.getElementById("my_button").onclick = function(){
			var res = verifyCode.validate(document.getElementById("code_input").value);
			if(res){
				alert("验证正确");

			}else{
				alert("验证码错误");
				return false;
			}
		}
	</script>
</html>