<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:77:"C:\Software\AppServ\www\flowerTP/application/index\view\index\showflower.html";i:1592922896;s:24:"./public/common/top.html";i:1593876542;s:25:"./public/common/left.html";i:1592887945;}*/ ?>
<meta charset="utf-8">
<center>
<table width=999px border=0>
<tr>
<td rowspan=2><img src="/flowerTP/public/static/image/logo.jpg" style="width:216px; height:68px"> </td>

<td style="font-size:x-small;">

<?php echo \think\Session::get('email'); ?>欢迎光临鲜花礼品网</td>
<td style="background:url('/flowerTP/public/static/image/topxmenubg.jpg'); font-size:x-small;text-align:center;">
<a href="member.php" style="text-decoration:none;">我的帐户</a>|
<a href="<?php echo url('order/showorder'); ?>" style="text-decoration:none;">我的订单</a>|
<a href="<?php echo url('cart/index'); ?>" style="text-decoration:none;">购物车</a>|
</td>
</tr>
<tr>
<td>
<?php if(\think\Session::get('email') == ''): ?>
<a href="<?php echo url('login/login'); ?>" style="font-size:x-small;text-decoration:none;">登录</a>&nbsp;&nbsp;
<?php else: ?>
<a href="<?php echo url('login/logOut'); ?>" style="font-size:x-small;text-decoration:none;">退出</a>&nbsp;&nbsp;
<?php endif; ?>

<a href="<?php echo url('admin/adminlogin/login'); ?>" style="font-size:x-small;text-decoration:none;">后台登录</a>&nbsp;&nbsp;</td>
<td style="text-align:right;"><img src="/flowerTP/public/static/image/ttel.jpg"></td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/bg-navbox.png'); font-size: small;text-align:center; width:999px;height:40px">
 <span style=" color:White;"> |</span> &nbsp; &nbsp; &nbsp;
    <a href="<?php echo url('index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体"> 主页</span></a>
    &nbsp;&nbsp;&nbsp; <span style=" color:White;"> |</span> &nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('index/showflower'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">鲜花</span></a>
     &nbsp; &nbsp; &nbsp; <span style=" color:White;"> |</span>&nbsp;&nbsp;&nbsp;
</td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/search_bg.jpg'); font-size: small;text-align:center; width:999px;height:35px">
<span style="font-weight:bold; font-size:x-small; font-family:宋体">
</span>
</td>
</tr>
</table></center>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>鲜花显示</title>
<link href="/flowerTP/public/static/css/StyleIndex.css" rel="stylesheet" type="text/css">

</head>
<body>
<center>
<div class="content">
<div class="left">
<meta charset="utf-8">
<!-- Left开始Start-->
    <div class="left">
    <div class="one">
        <div class="left1">&nbsp;&nbsp;&nbsp;&nbsp;鲜花导购</div>
        <div class="left2">&nbsp;<img alt="" src="/flowerTP/public/static/image/ico_1.gif" /> 按用途选购</div>
        <div class="left3">
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass&pvalue=爱情鲜花">爱情鲜花</a>|
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass&pvalue=友情鲜花">友情鲜花</a>|
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass&pvalue=生日鲜花">生日鲜花</a><br />
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass&pvalue=问候长辈">问候长辈</a>|
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass&pvalue=回报老师">回报老师</a>|
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass&pvalue=开业乔迁">开业乔迁</a><br  />
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass&pvalue=婚庆鲜花">婚庆鲜花</a>|
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass&pvalue=探病慰问">探病慰问</a>|
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass&pvalue=生子祝贺">生子祝贺</a><br  />
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass&pvalue=道歉鲜花">道歉鲜花</a>|
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass&pvalue=家居鲜花">家居鲜花</a>|
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass&pvalue=丧葬哀思">丧葬哀思</a><br  />
        </div> 
 
        <div class="left2"><img alt="" src="/flowerTP/public/static/image/ico_1.gif" /> 按花材选购</div>
        <div class="left3">
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass1&pvalue=玫瑰">玫瑰</a>|
			<a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass1&pvalue=康乃馨">康乃馨</a>|
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass1&pvalue=郁金香">郁金香</a>|
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass1&pvalue=百合">百合</a>|<br />
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass1&pvalue=扶郎">扶郎</a>|
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass1&pvalue=马蹄莲">马蹄莲</a>|
			<a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass1&pvalue=向日葵">向日葵 </a>|
			<a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass1&pvalue=菊花">菊花</a>|<br />
			<a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass1&pvalue=蓝色妖姬">蓝色妖姬 </a>|
			<a href="<?php echo url('showflower/clsflower'); ?>?pname=fclass1&pvalue=红掌">红掌 </a>|
      
        </div>
        <div class="left2"><img alt="" src="/flowerTP/public/static/image/ico_1.gif" /> 按价格选购</div>
        <div class="left3">       
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=tejia&pvalue=是">特价鲜花</a> |&nbsp; <a href="<?php echo url('showflower/clsflower'); ?>?pname=yourprice&pvalue1=0&pvalue2=100">100元以下鲜花</a>|<br />
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=yourprice&pvalue1=100&pvalue2=200">100-200元</a>|&nbsp; <a href="<?php echo url('showflower/clsflower'); ?>?pname=yourprice&pvalue1=200&pvalue2=300">200-300元</a>| <br />
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=yourprice&pvalue1=300&pvalue2=500">300-500元</a>|&nbsp; <a href="<?php echo url('showflower/clsflower'); ?>?pname=yourprice&pvalue1=500&pvalue2=800">500-800元</a>| <br />
            <a href="<?php echo url('showflower/clsflower'); ?>?pname=yourprice&pvalue1=800&pvalue2=20000">800元以上</a>|&nbsp;<br />
        </div>
     </div>
     
     <div class="one">
        <div class="left11">&nbsp;&nbsp;&nbsp;&nbsp;蛋糕礼品导购</div>
        <div class="left2"><img alt="" src="/flowerTP/public/static/image/ico_1.gif" /> 蛋糕品牌</div>
        <div class="left3">
            <a href="ByPrice.php?price=特价" >全国蛋糕</a>&nbsp;|
            <a href="ByPrice.php?price=0-100">一品轩蛋糕</a>&nbsp;| <br />
            <a href="ByPrice..php?price=100-200" >元祖蛋糕</a>&nbsp;|
            <a href="ByPrice.php?price=200-300">好利来蛋糕</a> | <br />
        </div>
        
       <div class="left2"><img alt="" src="/flowerTP/public/static/image/ico_1.gif" /> 蛋糕分类</div>
        <div class="left3">
            <a href="flowerClass.php?fclass=鲜奶蛋糕">鲜奶蛋糕</a>|<a href="flowerClass.php?fclass=水果蛋糕">水果蛋糕</a>|<a href="flowerClass.php?fclass=巧克力蛋糕">巧克力蛋糕</a>|<br />
            <a href="flowerClass.php?fclass=生肖蛋糕">生肖蛋糕</a>|<a href="flowerClass.php?fclass=情人蛋糕" >情人蛋糕</a>|<a href="flowerClass.php?fclass=婚庆蛋糕">婚庆蛋糕</a>|<br  />
            <a href="flowerClass.php?fclass=祝寿蛋糕">祝寿蛋糕</a>|<a href="flowerClass.php?fclass=儿童蛋糕" >儿童蛋糕</a>|<a href="flowerClass.php?fclass=欧式蛋糕">欧式蛋糕</a>|<br  />
            <a href="flowerClass.php?fclass=节庆蛋糕">节庆蛋糕</a>|<a href="flowerClass.php?fclass=慕斯蛋糕" >慕斯蛋糕</a>|<a href="flowerClass.php?fclass=无糖蛋糕">无糖蛋糕|</a><br  />
        </div>   
     </div>
     
     
     <div class="one">
        <div class="left2"><img alt="" src="/flowerTP/public/static/image/ico_1.gif" /> 礼品中心</div>
        <div class="left3">
            <a href="flowerClass.php?fclass=品牌公仔">品牌公仔</a>|<a href="flowerClass.php?fclass=卡通花束">卡通花束</a>|<a href="flowerClass.php?fclass=泰国保鲜花">泰国保鲜花</a>|<br />
            <a href="flowerClass.php?fclass=蛋糕毛巾">蛋糕毛巾</a>|<a href="flowerClass.php?fclass=茶具/酒具">茶具/酒具</a>|<a href="flowerClass.php?fclass=金箔花">金箔花</a>|<br  />
            <a href="flowerClass.php?fclass=祝寿蛋糕">音乐睡枕/抱枕/按摩枕系列</a> | <br  />
        </div> 
    </div>
    
     <div class="one">
  
        <div class="left12">&nbsp;&nbsp;&nbsp;&nbsp;城市专区</div>
        <div class="left3">
            <a href="" >深圳花店</a>|<a href="" >北京花店</a>|<a href="" >上海花店</a>|<br />
            <a href="" >广州花店</a>|<a href="" >成都花店</a>|<a href="" >西安花店</a>|<br  />
        </div> 
   </div>
   

     <div class="one">
        <div class="left13"></div>
        <div class="left3"><img src="/flowerTP/public/static/image/khfw.JPG" /></div>
    </div>
    </div>
    <!-- Left结束End -->
    
</div>

<div class="right">

<div class="page"><?php echo $page; ?></div>

<?php foreach($result as $flower): ?> 

<table style='width:700px;border-width:1px;border-style:dotted;' align=center>
     <tr>
        <td rowspan=7 width=170>
        <a href="flowerDetail.php?flowerID=<?php echo $flower['flowerID']; ?>"><img src="/flowerTP/public/static/picture/<?php echo $flower['picturem']; ?>" border=0/>
        </a></td>
        <td colspan=2 align=center><div style='font-weight:bold;font-size:medium;height:40px;line-height:40px;color:#000066;text-align:center;border-width:1px;  border-style:solid;border-color:red;'>
           <?php echo $flower['fname']; ?></div></td>          	
     </tr>
     <tr>
       <td width=50><font size=2>材料：</font></td>
       <td><font size=2><?php echo $flower['cailiao']; ?></font></td> 
     </tr>
     <tr>
     	<td width=50><font size=2>包装：</font></td>
     	<td><font size=2><?php echo $flower['baozhuang']; ?></font></td>
     </tr>
    <tr>
     	<td width=50><font size=2>花语：</font></td>
     	<td><font size=2><?php echo $flower['huayu']; ?></font></td>
     </tr>
     <tr>
     	<td width=50><font size=2>说明：</font></td>
     	<td><font size=2><?php echo $flower['shuoming']; ?></font></td>
     </tr>
     <tr>
     	<td colspan=2><div style='text-align:left;font-size: medium; color: #000066;'>
     	<div style='text-decoration:line-through;margin-top:8px;'>原价:￥1580</div>
     	现价：<font size=4 color=red><b>￥1280</b></font></div>
     	</td>
     </tr>
     <tr>
     	<td colspan=2><a href='/flowerTP/index.php/index/cart/addcart.html?flowerID=<?php echo $flower['flowerID']; ?>'>
<img src="/flowerTP/public/static/image/ingwc_ico.jpg" border="0"/></a></td>
     </tr>
</table>

 <?php endforeach; ?>

<div class="page"><?php echo $page; ?></div>
</div>
</center>
</body>
</html>