<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:75:"C:\Software\AppServ\www\bigHomework/application/index\view\index\index.html";i:1594273437;s:25:"./public/common/top2.html";i:1594272374;s:28:"./public/common/bottom2.html";i:1594181311;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN" style="width: 100%;">
<head>
	<meta charset="utf-8">
	<!--设备适配-->
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0.5, maximum-scale=2.0, user-scalable=no">
	<!--适配ie-->
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>书虫网</title>
	 <!-- Favicon -->
    <link rel="icon" href="/bigHomework/public/static/assets/images/favicon.ico" type="text/css">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="/bigHomework/public/static/css/bootstrap.min.css" type="text/css">
	<!-- animate CSS -->
	<link rel="stylesheet" href="/bigHomework/public/static/css/animate.min.css" type="text/css">
	<!-- MYCSS -->
	<link rel="stylesheet" type="text/css" href="/bigHomework/public/static/css/index.css" type="text/css">
	<!-- icon -->
	<link rel="stylesheet" href="/bigHomework/public/static/assets/font/iconfont.css" type="text/css"> 
	<!-- bootsnav -->
	<link rel="stylesheet" href="/bigHomework/public/static/css/bootsnav.css"  type="text/css"/>
	<link rel="stylesheet" href="/bigHomework/public/static/assets/font-awesome-4.7.0/css/font-awesome.css"  type="text/css"/>
	<link rel="stylesheet" href="/bigHomework/public/static/css/buttons.min.css" type="text/css"/>
	<base target="_self">

	
	   
</head>
<body style="width: 100%;">


<!--main header navbar-->

	<div class="container">
		
			<div class="row">		
			<div class="col-md-12">		
			<nav class="navbar navbar-default navbar-mobile bootsnav on">		
			<div class="navbar-header">	
			<a class="navbar-brand" href="#">
				<span class="bz">书虫网</span>
			</a>
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">		
			<i class="fa fa-bars"></i>		
			</button>		
	</div>	
	<div class="collapse navbar-collapse" id="navbar-menu">		
			<ul class="nav navbar-nav navbar-left" data-in="fadeInDown" data-out="fadeOutUp">
				<li><a href="<?php echo url('index/index'); ?>">主页</a></li>
				<li><a href="<?php echo url('index/showflower'); ?>">书目</a></li>

			</ul>
			<ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">

				<li><a href="<?php echo url('order/showorder'); ?>">我的订单</a></li>
				<?php if(\think\Session::get('email') == ''): ?>
				<li><a href="<?php echo url('login/login'); ?>">登录/注册</a></li>
				<?php else: ?>
				<li><a href="<?php echo url('login/logOut'); ?>">退出</a></li>
				<?php endif; ?>
				<li><a href="<?php echo url('admin/adminlogin/login'); ?>">后台登录</a></li>
				
			</ul>
	
			</div>
		</nav>
	</div>
	</div>
	</div>

	<!-- 搜索 -->
	<div class="dsc-search">
				<div class="form">
					<form id="searchForm" method="post"
						action="<?php echo url('index/index'); ?>"class="search-form">
						<input name="fname" type="text" id="keyword" class="search-text" />
						<button type="submit"class="button button-caution  button-border">搜</button>
					</form>
					<ul class="keyword">
						<li><a href="#" target="_blank">C基础开发</a></li>
						<li><a href="#" target="_blank">Java开发实战</a></li>
						<li><a href="#" target="_blank">Php开发</a></li>
						<li><a href="#" target="_blank">Node.js从深入简</a></li>
					</ul>
	
					<div class="suggestions_box" id="suggestions" style="display: none;">
						<div class="suggestions_list" id="auto_suggestions_list">&nbsp;</div>
					</div>
	
				</div>
	</div>
<!-- 购物车 -->
	<div class="shopCart" data-ectype="dorpdown" id="ECS_CARTINFO"
				data-carteveval="0" >
				<div class="shopCart-con dsc-cm">
					<a href="<?php echo url('cart/index'); ?>" "> 
							<!-- 	<span style="color: red;">我的购物车</span> -->
						<button class="button button-caution button-glow button-border">购物车</button>
					</a>
				</div>
</div>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery.-1.10.2.min.js"></script>	
<script type="text/javascript" src="/bigHomework/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery-1.10.2.animate.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/assets/font/iconfont.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/bootsnav.js"></script>
<script type="text/javascript"  src="/bigHomework/public/static/js/buttons.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery.fadethis.min.js"></script>
<script>
			$(window).fadeThis();
</script>
 <script>
     $(document).ready(function(){
        $(".dropdown-toggle").hover(function());
      });
</script>

			
			
			
			
			
		
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			

<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<link href="/bigHomework/public/static/css/prodList.css" rel="stylesheet" type="text/css">
	<link href="/bigHomework/public/static/css/StyleIndex.css" rel="stylesheet" type="text/css">
</head>
<body>
<center>
<br/>
<br/>
<div id="content">
		<div id="search_div">
			<form method="post" action="<?php echo url('index/index'); ?>">
				<span class="input_span">商品名：<input type="text" name="fname"/></span>
				<span class="input_span">出版商：
				<select name="fclass">
				<Option value="">不限</option>
				<?php foreach($fclasses as $fclass): ?>
				<Option value = "<?php echo $fclass['publisher']; ?>"><?php echo $fclass['publisher']; ?></Option>
				<?php endforeach; ?>
				</select>
				</span>
				<span class="input_span">商品价格区间：<input type="text" name="minprice" value="0"/> - <input type="text" name="maxprice"  value="1000"/></span>
				<input type="submit" value="查 询">
			</form>
		</div>


	<div id="prod_content">
	
	<?php foreach($flowers as $flower): ?>
		<div class="prod_div">
			<a href="/bigHomework/index.php/index/showflower/flowerdetail.html?bookID=<?php echo $flower['bookID']; ?>">
				<img src="/bigHomework/public/static/picture/<?php echo $flower['picturem']; ?>" border="0"/>
			</a>
				<div id="prod_name_div"><?php echo $flower['bname']; ?></div>
				<div id="prod_price_div">￥<?php echo $flower['yourprice']; ?>元</div>
				<div>
					<div id="gotocart_div">
					<a href='<?php echo url('cart/addCart'); ?>?bookID=<?php echo $flower['bookID']; ?>'>
					加入购物车
					</a>
					</div>					
					<div id="say_div"><?php echo $flower['SelledNum']; ?>人购买</div>					
				</div>
			</div>
<?php endforeach; ?>
			<div style="clear: both"></div>
	</div>
</div>

</div>
	<!DOCTYPE html>
<html lang="zh-CN" style="width: 100%;">
<head>
	<meta charset="utf-8">
	<!--设备适配-->
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0.5, maximum-scale=2.0, user-scalable=no">
	<!--适配ie-->
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>书虫网</title>
	 <!-- Favicon -->
    <link rel="icon" href="/bigHomework/public/static/assets/images/favicon.ico">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="/bigHomework/public/static/css/bootstrap.min.css">
	<!-- animate CSS -->
	<link rel="stylesheet" href="/bigHomework/public/static/css/animate.min.css">
	<!-- MYCSS -->
	<link rel="stylesheet" type="text/css" href="/bigHomework/public/static/css/index.css">
	<!-- icon -->
	<link rel="stylesheet" href="/bigHomework/public/static/assets/font/iconfont.css">
	<!-- bootsnav -->
	<link rel="stylesheet" href="/bigHomework/public/static/css/bootsnav.css" />
	<link rel="stylesheet" href="/bigHomework/public/static/assets/font-awesome-4.7.0/css/font-awesome.css" />
	<link rel="stylesheet" href="/bigHomework/public/static/css/buttons.min.css"/>
	<base target="_blank" />
</head>
<body style="width: 100%;">
			
<div id="he-plugin-simple"></div>

		            <footer class="footer-area section-gap">
										
		                <div class="container">
		                    <div class="row">
		                        <div class="col-lg-5 col-md-6 col-sm-6">
		                            <div class="single-footer-widget">
		                                <h4>书虫网</h4>
		                                <p>
		                                   科学家不依靠个人的思想，而是融合了数千人的智慧。 所有人都想到一个问题，每个人都在做自己的工作，这增加了正在建立的知识的基础
		                                </p>
		                                <p class="footer-text">
		Copyright &copy;<script>document.write(new Date().getFullYear());</script> Designed&nbsp;<i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">BZ</a>
</p>
		                            </div>
		                        </div>
		                        <div class="col-lg-5 col-md-6 col-sm-6">
		                            <div class="single-footer-widget">
		                                <h4>常用网站</h4>
		                               
										<div class="" id="mc_embed_signup">								
											<ul class="link" style="margin: 0;padding: 0;">
											    <li style="list-style:none;"><a href="https://www.githubs.cn/" >Github</a></li>
											    <li style="list-style:none;"><a href="https://www.baidu.com/" >Baidu</a></li>
											    <li style="list-style:none;"><a href="https://www.w3school.com.cn/">W3school</a></li>
											</ul>
										</div>
		                            </div>
		                        </div>
		                        <div class="col-lg-2 col-md-6 col-sm-6 social-widget">
		                            <div class="single-footer-widget">
		                                <h4>联系我们</h4>
		                                <p>Let us be social</p>
		                                <div class="footer-social d-flex align-items-center">
		                                    <a href="#"><i class="fa fa-qq"></i></a>
		                                    <a href="#"><i class="fa fa-weixin"></i></a>
		                                    <a href="#"><i class="fa fa-weibo"></i></a>
		                                    <a href="#"><i class="fa fa-twitter"></i></a>
		                                </div>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		            </footer>
		            <!-- End footer Area -->		

<script type="text/javascript" src="/bigHomework/public/static/js/jquery.-1.10.2.min.js"></script>	
<script type="text/javascript" src="/bigHomework/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery-1.10.2.animate.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/assets/font/iconfont.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/bootsnav.js"></script>
<script type="text/javascript"  src="/bigHomework/public/static/js/buttons.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery.fadethis.min.js"></script>
<script>
			$(window).fadeThis();
</script>
 <script>
     $(document).ready(function(){
        $(".dropdown-toggle").hover(function());
      });
</script>


</body>

</html>
</center>
</body>
</html>