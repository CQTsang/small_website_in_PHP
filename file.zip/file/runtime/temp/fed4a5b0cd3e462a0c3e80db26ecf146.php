<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:74:"C:\Software\AppServ\www\bigHomework/application/index\view\cart\index.html";i:1594228357;s:25:"./public/common/top2.html";i:1594272374;s:28:"./public/common/bottom2.html";i:1594181311;}*/ ?>
﻿<!DOCTYPE html>
<html lang="zh-CN" style="width: 100%;">
<head>
	<meta charset="utf-8">
	<!--设备适配-->
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0.5, maximum-scale=2.0, user-scalable=no">
	<!--适配ie-->
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>书虫网</title>
	 <!-- Favicon -->
    <link rel="icon" href="/bigHomework/public/static/assets/images/favicon.ico" type="text/css">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="/bigHomework/public/static/css/bootstrap.min.css" type="text/css">
	<!-- animate CSS -->
	<link rel="stylesheet" href="/bigHomework/public/static/css/animate.min.css" type="text/css">
	<!-- MYCSS -->
	<link rel="stylesheet" type="text/css" href="/bigHomework/public/static/css/index.css" type="text/css">
	<!-- icon -->
	<link rel="stylesheet" href="/bigHomework/public/static/assets/font/iconfont.css" type="text/css"> 
	<!-- bootsnav -->
	<link rel="stylesheet" href="/bigHomework/public/static/css/bootsnav.css"  type="text/css"/>
	<link rel="stylesheet" href="/bigHomework/public/static/assets/font-awesome-4.7.0/css/font-awesome.css"  type="text/css"/>
	<link rel="stylesheet" href="/bigHomework/public/static/css/buttons.min.css" type="text/css"/>
	<base target="_self">

	
	   
</head>
<body style="width: 100%;">


<!--main header navbar-->

	<div class="container">
		
			<div class="row">		
			<div class="col-md-12">		
			<nav class="navbar navbar-default navbar-mobile bootsnav on">		
			<div class="navbar-header">	
			<a class="navbar-brand" href="#">
				<span class="bz">书虫网</span>
			</a>
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">		
			<i class="fa fa-bars"></i>		
			</button>		
	</div>	
	<div class="collapse navbar-collapse" id="navbar-menu">		
			<ul class="nav navbar-nav navbar-left" data-in="fadeInDown" data-out="fadeOutUp">
				<li><a href="<?php echo url('index/index'); ?>">主页</a></li>
				<li><a href="<?php echo url('index/showflower'); ?>">书目</a></li>

			</ul>
			<ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">

				<li><a href="<?php echo url('order/showorder'); ?>">我的订单</a></li>
				<?php if(\think\Session::get('email') == ''): ?>
				<li><a href="<?php echo url('login/login'); ?>">登录/注册</a></li>
				<?php else: ?>
				<li><a href="<?php echo url('login/logOut'); ?>">退出</a></li>
				<?php endif; ?>
				<li><a href="<?php echo url('admin/adminlogin/login'); ?>">后台登录</a></li>
				
			</ul>
	
			</div>
		</nav>
	</div>
	</div>
	</div>

	<!-- 搜索 -->
	<div class="dsc-search">
				<div class="form">
					<form id="searchForm" method="post"
						action="<?php echo url('index/index'); ?>"class="search-form">
						<input name="fname" type="text" id="keyword" class="search-text" />
						<button type="submit"class="button button-caution  button-border">搜</button>
					</form>
					<ul class="keyword">
						<li><a href="#" target="_blank">C基础开发</a></li>
						<li><a href="#" target="_blank">Java开发实战</a></li>
						<li><a href="#" target="_blank">Php开发</a></li>
						<li><a href="#" target="_blank">Node.js从深入简</a></li>
					</ul>
	
					<div class="suggestions_box" id="suggestions" style="display: none;">
						<div class="suggestions_list" id="auto_suggestions_list">&nbsp;</div>
					</div>
	
				</div>
	</div>
<!-- 购物车 -->
	<div class="shopCart" data-ectype="dorpdown" id="ECS_CARTINFO"
				data-carteveval="0" >
				<div class="shopCart-con dsc-cm">
					<a href="<?php echo url('cart/index'); ?>" "> 
							<!-- 	<span style="color: red;">我的购物车</span> -->
						<button class="button button-caution button-glow button-border">购物车</button>
					</a>
				</div>
</div>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery.-1.10.2.min.js"></script>	
<script type="text/javascript" src="/bigHomework/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery-1.10.2.animate.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/assets/font/iconfont.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/bootsnav.js"></script>
<script type="text/javascript"  src="/bigHomework/public/static/js/buttons.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery.fadethis.min.js"></script>
<script>
			$(window).fadeThis();
</script>
 <script>
     $(document).ready(function(){
        $(".dropdown-toggle").hover(function());
      });
</script>

			
			
			
			
			
		
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>购物车</title>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery-1.4.2.js"></script>
<script type="text/javascript">
$().ready(function(){
	sum();
	total();
	chk();
	console.log('hhh');
})

function sum(){
	$('#goods tr').each(function(){
		var price = parseFloat($(this).find("td:eq(4)").text());
		var num = parseInt($(this).find("input[name='num']").val());
		$(this).find("td:eq(6)").text(price*num);
	})
}

function total(){
	var s = 0;
	$('#goods tr').each(function(){
		if($(this).find("input[type='checkbox']").attr('checked')){
			var prices = parseFloat($(this).find("td:eq(6)").text());
			s+=prices;
		}
	})
	$("#total").text(s);
}

function change(btn,o){
	var num=0;
	num = $('#'+o).val();
	var flag = 0;
	for(var i = 0;i<num.length;i++)
	{
		if((num.charCodeAt(i)>57 || num.charCodeAt(i)<48) && num.charAt(i)!=32){
			flag=1;
			break;
	}}
		if(flag==1){
			alert("数量只能是数字！");
			return false;
		}
		else{
			var tds = $(btn).parent().siblings();
			var yourprice = tds.eq(4).text();
			tds.eq(5).text(yourprice*num);
			total();
			$.get("<?php echo url('cart/updateCart'); ?>",{"cartID":o,"num":num});
		}
	}
	
function del(btn,cid){
	$(btn).parent().parent().remove();
	total();
	$.get("<?php echo url('cart/deleteCart'); ?>",{"cartID":cid});
}

function chk(){
	total();
}

</script>

</head>
<body>
<center>

<img src="/bigHomework/public/static/image/cartbg1.jpg"><br/><br/>
<form action="<?php echo url('order/order'); ?>" name="form1" method="post">
<table style="width:881px;border-width:1px; border-style:groove;font-size:x-small;">
<tr style="background:url('/bigHomework/public/static/image/cartbg.jpg'); text-align:center;font-weight:bold; border-width:1px; border-style:groove;">
<td>选择</td><td>编号</td><td>商品名称</td><td>市场价</td><td>现价</td><td>数量</td><td>金额</td><td>删除商品</td>
</tr> 

<tbody id="goods">

<?php $sum = '0'; foreach($result as $cart): $sum = $sum+ $cart['yourprice'] *  $cart['num']; ?>

<tr style='text-align:center;height:50px;line-height:50px;'>
<td><input type='checkbox' name='cartID[]'
							value='<?php echo $cart['cartID']; ?>' checked onclick="chk()"></td>
<td><?php echo $cart['cartID']; ?></td>

<td><div style='height:50px; float:left;'>
<img src='/bigHomework/public/static/picture/<?php echo $cart['pictures']; ?>' width=48 height=51 border=0></div>
<div style='height:50px; float:left;'><?php echo $cart['bname']; ?></div>
</td>

<td><?php echo $cart['price']; ?></td>
<td><?php echo $cart['yourprice']; ?></td>

<td><input type='text' id='<?php echo $cart['cartID']; ?>' size='1' value='<?php echo $cart['num']; ?>' name='num'>
<input type='button' onclick='change(this,<?php echo $cart['cartID']; ?>)' value='更新' /></td>
<td></td>
<td>
<input type="image" onclick="del(this,<?php echo $cart['cartID']; ?>);" width="41" height="20"
		src="/bigHomework/public/static/image/04shop_deleteID.gif">
</td>
</tr>
<?php endforeach; ?>
</tbody>
				<tr>
					<td colspan="6" align="right">总计:￥</td>
					<td id="total" align="right"
						style="color: red; font-size: 16px; font-bold: true;"><?php echo $sum; ?></td>
					<td>元</td>
				</tr>
 </table>
</form>

<div style="float:center;width:881;text-align:center;">
<a href="<?php echo url('index/index'); ?>"><img src="/bigHomework/public/static/image/continue.jpg" border=0></a>&nbsp;
<a href="<?php echo url('cart/clearCart'); ?>"><img src="/bigHomework/public/static/image/clearCart.jpg" border=0></a>&nbsp;
<input type='image' src='/bigHomework/public/static/image/submitOrder.jpg' onclick='javascript:form1.submit()'>
</div>
 </center>
<!DOCTYPE html>
<html lang="zh-CN" style="width: 100%;">
<head>
	<meta charset="utf-8">
	<!--设备适配-->
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0.5, maximum-scale=2.0, user-scalable=no">
	<!--适配ie-->
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>书虫网</title>
	 <!-- Favicon -->
    <link rel="icon" href="/bigHomework/public/static/assets/images/favicon.ico">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="/bigHomework/public/static/css/bootstrap.min.css">
	<!-- animate CSS -->
	<link rel="stylesheet" href="/bigHomework/public/static/css/animate.min.css">
	<!-- MYCSS -->
	<link rel="stylesheet" type="text/css" href="/bigHomework/public/static/css/index.css">
	<!-- icon -->
	<link rel="stylesheet" href="/bigHomework/public/static/assets/font/iconfont.css">
	<!-- bootsnav -->
	<link rel="stylesheet" href="/bigHomework/public/static/css/bootsnav.css" />
	<link rel="stylesheet" href="/bigHomework/public/static/assets/font-awesome-4.7.0/css/font-awesome.css" />
	<link rel="stylesheet" href="/bigHomework/public/static/css/buttons.min.css"/>
	<base target="_blank" />
</head>
<body style="width: 100%;">
			
<div id="he-plugin-simple"></div>

		            <footer class="footer-area section-gap">
										
		                <div class="container">
		                    <div class="row">
		                        <div class="col-lg-5 col-md-6 col-sm-6">
		                            <div class="single-footer-widget">
		                                <h4>书虫网</h4>
		                                <p>
		                                   科学家不依靠个人的思想，而是融合了数千人的智慧。 所有人都想到一个问题，每个人都在做自己的工作，这增加了正在建立的知识的基础
		                                </p>
		                                <p class="footer-text">
		Copyright &copy;<script>document.write(new Date().getFullYear());</script> Designed&nbsp;<i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">BZ</a>
</p>
		                            </div>
		                        </div>
		                        <div class="col-lg-5 col-md-6 col-sm-6">
		                            <div class="single-footer-widget">
		                                <h4>常用网站</h4>
		                               
										<div class="" id="mc_embed_signup">								
											<ul class="link" style="margin: 0;padding: 0;">
											    <li style="list-style:none;"><a href="https://www.githubs.cn/" >Github</a></li>
											    <li style="list-style:none;"><a href="https://www.baidu.com/" >Baidu</a></li>
											    <li style="list-style:none;"><a href="https://www.w3school.com.cn/">W3school</a></li>
											</ul>
										</div>
		                            </div>
		                        </div>
		                        <div class="col-lg-2 col-md-6 col-sm-6 social-widget">
		                            <div class="single-footer-widget">
		                                <h4>联系我们</h4>
		                                <p>Let us be social</p>
		                                <div class="footer-social d-flex align-items-center">
		                                    <a href="#"><i class="fa fa-qq"></i></a>
		                                    <a href="#"><i class="fa fa-weixin"></i></a>
		                                    <a href="#"><i class="fa fa-weibo"></i></a>
		                                    <a href="#"><i class="fa fa-twitter"></i></a>
		                                </div>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		            </footer>
		            <!-- End footer Area -->		

<script type="text/javascript" src="/bigHomework/public/static/js/jquery.-1.10.2.min.js"></script>	
<script type="text/javascript" src="/bigHomework/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery-1.10.2.animate.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/assets/font/iconfont.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/bootsnav.js"></script>
<script type="text/javascript"  src="/bigHomework/public/static/js/buttons.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery.fadethis.min.js"></script>
<script>
			$(window).fadeThis();
</script>
 <script>
     $(document).ready(function(){
        $(".dropdown-toggle").hover(function());
      });
</script>


</body>

</html>