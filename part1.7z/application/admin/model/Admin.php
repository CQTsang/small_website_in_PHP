<?php
namespace app\admin\model;

use think\Model;

class Admin extends Model
{
}

