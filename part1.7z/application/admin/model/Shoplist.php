<?php
namespace app\admin\model;

use think\Model;

class Shoplist extends Model
{
}

