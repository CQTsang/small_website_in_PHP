<?php
namespace app\index\controller;

use think\Controller;
use think\Db;
class Cart extends Controller
{
    public function addCart(){
        $param = input('get.');
        if(empty(session('email'))){
            $this->error('请先登录!','login/index');
        }
        if(empty($param['bookID'])){
            $this->error('请选择商品！','index/index');
        }
        
        $data = Db::table('cart')->where('email',session('email'))->where('bookID',$param['bookID'])->find();
        //$data = Db::table('cart')->where("email='".session('email')."' and flowerID='".$param['flowerID']."'")->find();
        if(empty($data)){
            $result = Db::execute("insert into cart(cartID,email,bookID,num) values(null,'" . session('email') . "','" .$param['bookID']. "',1)");
//             dump($result);
        }else{
         			$result=Db::execute("update cart set num=num+1 where email='" .session('email'). "' and bookID='" . $param['bookID'] . "'");
//          			dump($result);
        }        
       $this->redirect(url('cart/index'));
         
    }
    
    public function index(){
        if(empty(session('email'))){
            $this->error('请先登录!','login/index');
        }
        $data=Db::table('vcart')->where('email',session('email'))->select();
    
        $this->assign('result',$data);
        return$this->fetch();
}

public function updateCart(){  //改数据库的
    $param = input('get.');
    $result=Db::execute("update cart set num=".$param['num']." where cartID=".$param['cartID']);
    //dump($result);
    
    $this->redirect(url('cart/index'));
}

public function deleteCart(){
    $param = input('get.');
    $result=Db::execute("delete from cart where cartID=".$param['cartID']);
//     dump($result);
    $this->redirect(url('cart/index'));
}

public function clearCart(){
   $result=Db::execute("delete from cart where email='" .session('email'). "'");
   $this->redirect(url('cart/index'));
}

}
