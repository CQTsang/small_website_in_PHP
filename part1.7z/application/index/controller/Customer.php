<?php
namespace app\index\controller;

use think\Controller;
use app\index\model\Customer;

class Customer extends Controller
{
    public function addCustomer(){
//         $custID = input('post.custID');
        $customer = new Customer();
        $customer->sname =input('post.addName');
        $customer->mobile =  input('post.addPhone');
        $customer->address = input('post.address');
        $customer->email = input('post.buyemail');
        $customer->save();

        $search="sname='".$customer->sname."' and email='".$customer->email."' and mobile='".$customer->mobile."' and address='".$customer->address."'";
//         $search="sname='".$customer->sname."' and mobile='".$customer->mobile."' and address='".$customer->address."'";
            $customerN = Customer::where($search)->find();
            return $customerN->custID;
    }
    
    public function editCustomer(){
        $addName = input('post.addName');
        $mobile = input('post.addPhone');
        $address = input('post.address');
        $custID = input('post.custID');
        $cust = Customer::get($custID);
        if(!empty($addName)){
            $cust->sname=$addName;
        }
        if(!empty($mobile)){
            $cust->mobile = $mobile;
        }
        if(!empty($address)){
            $cust->address=$address;
        }
//         $cust->save();
        $cust->save();
        return "success";
    }
    
    public function deleteCustomer(){
        $custID = input('post.custID');
        $customer = Customer::get($custID);
        if($customer){
            $customer->delete();
            return "success";
        }
    }
    
    public function setDefault(){
        $custID  = input('post.custID/d');
        $originalID = input ('post.originalID/d');
        $oldDefault = Customer::get($originalID);
        
        $oldDefault->cdefault = '0';
        $oldDefault ->save();
        
        $newDefault = Customer::get($custID);
        $newDefault ->cdefault = '1';
        $newDefault->save();
        
        return "success";
    }
}

