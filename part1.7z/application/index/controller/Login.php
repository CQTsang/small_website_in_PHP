<?php
namespace app\index\controller;

use think\Controller;
use think\Db;
class Login extends Controller
{
    public function login(){
        return view();
    }
    
    public  function doLogin(){

        if(empty(input('post.email'))){
            $this->error('email不能为空');
        }
        $rs = db('tb_member')->where('email', input('post.email'))->find();
        if(empty($rs)){
            $this->error('邮箱错误');
        }
        if($rs['password'] != md5( input('post.passw'))){
            $this->error('密码错误');
        }

        session('email',$rs['email']);
        $this->redirect(url('index/index'));
    }
    
    public function logOut(){
        session('email',null);
        $this->redirect(url('index/index'));
    }
    
//     public function register(){
//         if(empty(input('post.emailNew'))) {
//             $this->error('email不能为空');
//         }
        
//         if(empty(input('post.nameNew'))) {
//             $this->error('用户名不能为空');
//         }
        
//         if(empty(input('post.passw1'))) {
//             $this->error('passw1不能为空');
//         }
//         if(empty(input('post.passw2'))) {
//             $this->error('passw2不能为空');
//         }
//         if(input('post.passw1')!=input('post.passw2')){
//             $this->error('两次密码输入不一致！');
//         }
        
//         $data = db('tb_member')->where('email', input('post.emailNew'))->find();  //使用了db助手
//         //$data = Db::table('tb_member')->where('email', input('post.mail'))->find();
//         if(!empty($data)) {
//             $this->error('该用户已被注册！');
//         }
//         else {
//             $result = Db::execute("insert into tb_member(email,password,jifen,ye) values('" . input('post.email') . "','" .md5(input('post.passw1')) . "',0,0)");
//             dump($result);
//             $this->redirect(url('index/index'));
//         }
//     }
}

