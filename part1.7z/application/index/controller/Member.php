<?php
namespace app\index\controller;

use think\Controller;
use app\index\model\Member;
class Member extends Controller
{
public function editMember(){
        $email = session('email');
        if(empty($email)){
            $this->error('请先登录!','login/login');
        }
        $mname = input('post.name');
        $mobile = input('post.phone');
        $member = Member::get($email);
        $member->mname=$mname;
        $member->mobile=$mobile;
        $member->save();
    }
    
}

