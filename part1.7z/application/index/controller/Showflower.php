<?php
namespace app\index\controller;

use think\Controller;
use app\index\model\Flower;
use app\index\model\Shoplist;
class Showflower extends Controller
{
    public function flowerdetail(){
//         $id = $_GET['id']
      //  $flowerID = input('get.flowerID');
        $flowerID = $_REQUEST['bookID'];
        $flower=Flower::get($flowerID);
        $this->assign('flower',$flower);
        $shoplists=Shoplist::where("bookID='".$flowerID."' and pjstar is not null")->select();
        $this->assign('shoplists',$shoplists);
//         dump($shoplists);
//         dump($flower);
        return $this->fetch('flowerdetail');
    }
}

