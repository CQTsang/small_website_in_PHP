<?php
namespace app\index\model;

use think\Model;

class Flower extends Model
{
    protected $table = 'book';
}

