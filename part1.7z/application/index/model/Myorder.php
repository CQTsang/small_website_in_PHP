<?php
namespace app\index\model;

use think\Model;

class Myorder extends Model
{
}

