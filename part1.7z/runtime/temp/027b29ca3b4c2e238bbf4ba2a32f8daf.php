<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:76:"C:\Software\AppServ\www\flowerTP/application/index\view\order\showorder.html";i:1594044851;s:24:"./public/common/top.html";i:1593876542;}*/ ?>
﻿<meta charset="utf-8">
<center>
<table width=999px border=0>
<tr>
<td rowspan=2><img src="/flowerTP/public/static/image/logo.jpg" style="width:216px; height:68px"> </td>

<td style="font-size:x-small;">

<?php echo \think\Session::get('email'); ?>欢迎光临鲜花礼品网</td>
<td style="background:url('/flowerTP/public/static/image/topxmenubg.jpg'); font-size:x-small;text-align:center;">
<a href="member.php" style="text-decoration:none;">我的帐户</a>|
<a href="<?php echo url('order/showorder'); ?>" style="text-decoration:none;">我的订单</a>|
<a href="<?php echo url('cart/index'); ?>" style="text-decoration:none;">购物车</a>|
</td>
</tr>
<tr>
<td>
<?php if(\think\Session::get('email') == ''): ?>
<a href="<?php echo url('login/login'); ?>" style="font-size:x-small;text-decoration:none;">登录</a>&nbsp;&nbsp;
<?php else: ?>
<a href="<?php echo url('login/logOut'); ?>" style="font-size:x-small;text-decoration:none;">退出</a>&nbsp;&nbsp;
<?php endif; ?>

<a href="<?php echo url('admin/adminlogin/login'); ?>" style="font-size:x-small;text-decoration:none;">后台登录</a>&nbsp;&nbsp;</td>
<td style="text-align:right;"><img src="/flowerTP/public/static/image/ttel.jpg"></td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/bg-navbox.png'); font-size: small;text-align:center; width:999px;height:40px">
 <span style=" color:White;"> |</span> &nbsp; &nbsp; &nbsp;
    <a href="<?php echo url('index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体"> 主页</span></a>
    &nbsp;&nbsp;&nbsp; <span style=" color:White;"> |</span> &nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('index/showflower'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">鲜花</span></a>
     &nbsp; &nbsp; &nbsp; <span style=" color:White;"> |</span>&nbsp;&nbsp;&nbsp;
</td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/search_bg.jpg'); font-size: small;text-align:center; width:999px;height:35px">
<span style="font-weight:bold; font-size:x-small; font-family:宋体">
</span>
</td>
</tr>
</table></center>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<link href="/flowerTP/public/static/css/orderList.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="/flowerTP/public/static/js/jquery-1.4.2.js"></script>
<style>
/*分页样式*/   
.pagination{text-align:center;margin-top:20px;margin-bottom: 20px;}  
.pagination li{margin:0px 10px; border:1px solid #e6e6e6;padding: 3px 8px;display: inline-block;}  
.pagination .active{background-color: #46A3FF;color: #fff;}  
.pagination .disabled{color:#aaa;} 
</style>

<script>
$(function(){
	$(".del").click(function(){
		var orderID = $(".del").attr("id");
		//alert(orderID);
		//$(".del").parents("div").hide();
		$.post("<?php echo url('order/delete'); ?>",{orderID:orderID},function(result){
			if(result == "success"){
				$(".del").parents("div").hide();
				window.location.href="<?php echo url('order/showorder'); ?>";
			}
		});
	})
})

</script>

</head>
<body>
<center>
    <div class="no_order_info" >
    <!-- 提示您暂时没有订单信息 -->
   <?php if($showorder == ''): ?>
   	您还没有添加任何订单！
   	<?php endif; ?>
    </div>
    <!-- 分页显示记录-->
<div class="pages"><?php echo $page; ?></div>

<!-- 模版数据 -start -->
  <?php foreach($showorder as $order): ?>
	<div style="margin: 0 auto;width:999px;">
		<dl class="Order_information">
			<dt><h3>订单信息</h3>	</dt>	
			<dd style="line-height: 26px;">
				订单编号：<?php echo $order['orderID']; ?>
				<br />
				下单时间：	<?php echo $order['inputtime']; ?>
				<br /> 
				订单金额：<?php echo $order['shifu']; ?>
				<br /> 
				订单状态：<?php echo $order['status']; ?>
				<!-- 订单状态判断 ，未付款订单允许删除！-->
				<?php switch($order['status']): case "未付款": ?>
							<font color="red"></font>&nbsp;&nbsp;
							<a class="del"  href="javascript:void(0)" id="<?php echo $order['orderID']; ?>" >
							<img src="/flowerTP/public/static/image/sc.jpg" width="69" height="19"/>
						</a>
						&nbsp;
				 		<a href="<?php echo url('order/pay'); ?>?id=<?php echo $order['orderID']; ?>&money=<?php echo $order['shifu']; ?>"> 
					 		<img src="/flowerTP/public/static/image/zx.jpg" width="69" height="19">
						</a>
				<?php break; case "已发货": ?>											
						<font color="blue"></font>&nbsp;&nbsp;		
						<a href="<?php echo url('order/orderUpdate'); ?>?orderID=<?php echo $order['orderID']; ?>">确认收货</a>	
				<?php break; default: ?><font color="blue"><?php echo $order['status']; ?></font>&nbsp;&nbsp;
				<?php endswitch; ?>
				<br /> 
				收货人：<?php echo $order['sname']; ?> 
				<br/> 
				收货地址：<?php echo $order['address']; ?>
				<br/> 
				支付方式：<?php echo $order['pay_with']; ?>
			</dd>
		</dl>
	
		<table width="999px" border="0" cellpadding="0"
			cellspacing="1" style="background:#d8d8d8;color:#333333">
			<tr>
				<th width="249" height="30" align="center" valign="middle" bgcolor="#f3f3f3">商品图片</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">商品名称</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">原价</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">现价</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">购买数量</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">总价</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">商品评价</th>
			</tr>
			<?php foreach($orderlists as $orderlist): foreach($orderlist as $shoplist): if(($order['orderID'] == $shoplist['orderID'])): ?>
			
			
			<tr>
				<td align="center" valign="middle" bgcolor="#FFFFFF">
				<a href="<?php echo url('showflower/flowerDetail'); ?>?flowerID=<?php echo $shoplist['flowerID']; ?>">
					<img src="/flowerTP/public/static/picture/<?php echo $shoplist['pictures']; ?>" border=0></a>
				</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['fname']; ?></td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['price']; ?>元</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['yourprice']; ?>元</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['num']; ?>件</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['num'] * $shoplist['yourprice']; ?>元</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF">
					<?php if(($order['status'] == '未评价')): ?>
						<a href=" <?php echo url('order/evaluate'); ?>?orderID=<?php echo $shoplist['orderID']; ?>">评价</a>
					<?php endif; ?>
				</td>
			</tr>
				
			<?php endif; endforeach; endforeach; ?>
		</table>		
		<div class="Order_price"><?php echo $order['shifu']; ?>元</div>	
	</div>

<?php endforeach; ?>
	<!-- 模版数据 -end -->
	<div class="pages"><?php echo $page; ?></div>
	</center>
</body>
</html>