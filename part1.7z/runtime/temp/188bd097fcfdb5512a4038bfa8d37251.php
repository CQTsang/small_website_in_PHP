<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:79:"C:\Software\AppServ\www\bigHomework/application/index\view\order\showorder.html";i:1594235659;s:25:"./public/common/top2.html";i:1594272374;}*/ ?>
﻿<!DOCTYPE html>
<html lang="zh-CN" style="width: 100%;">
<head>
	<meta charset="utf-8">
	<!--设备适配-->
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0.5, maximum-scale=2.0, user-scalable=no">
	<!--适配ie-->
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>书虫网</title>
	 <!-- Favicon -->
    <link rel="icon" href="/bigHomework/public/static/assets/images/favicon.ico" type="text/css">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="/bigHomework/public/static/css/bootstrap.min.css" type="text/css">
	<!-- animate CSS -->
	<link rel="stylesheet" href="/bigHomework/public/static/css/animate.min.css" type="text/css">
	<!-- MYCSS -->
	<link rel="stylesheet" type="text/css" href="/bigHomework/public/static/css/index.css" type="text/css">
	<!-- icon -->
	<link rel="stylesheet" href="/bigHomework/public/static/assets/font/iconfont.css" type="text/css"> 
	<!-- bootsnav -->
	<link rel="stylesheet" href="/bigHomework/public/static/css/bootsnav.css"  type="text/css"/>
	<link rel="stylesheet" href="/bigHomework/public/static/assets/font-awesome-4.7.0/css/font-awesome.css"  type="text/css"/>
	<link rel="stylesheet" href="/bigHomework/public/static/css/buttons.min.css" type="text/css"/>
	<base target="_self">

	
	   
</head>
<body style="width: 100%;">


<!--main header navbar-->

	<div class="container">
		
			<div class="row">		
			<div class="col-md-12">		
			<nav class="navbar navbar-default navbar-mobile bootsnav on">		
			<div class="navbar-header">	
			<a class="navbar-brand" href="#">
				<span class="bz">书虫网</span>
			</a>
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">		
			<i class="fa fa-bars"></i>		
			</button>		
	</div>	
	<div class="collapse navbar-collapse" id="navbar-menu">		
			<ul class="nav navbar-nav navbar-left" data-in="fadeInDown" data-out="fadeOutUp">
				<li><a href="<?php echo url('index/index'); ?>">主页</a></li>
				<li><a href="<?php echo url('index/showflower'); ?>">书目</a></li>

			</ul>
			<ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">

				<li><a href="<?php echo url('order/showorder'); ?>">我的订单</a></li>
				<?php if(\think\Session::get('email') == ''): ?>
				<li><a href="<?php echo url('login/login'); ?>">登录/注册</a></li>
				<?php else: ?>
				<li><a href="<?php echo url('login/logOut'); ?>">退出</a></li>
				<?php endif; ?>
				<li><a href="<?php echo url('admin/adminlogin/login'); ?>">后台登录</a></li>
				
			</ul>
	
			</div>
		</nav>
	</div>
	</div>
	</div>

	<!-- 搜索 -->
	<div class="dsc-search">
				<div class="form">
					<form id="searchForm" method="post"
						action="<?php echo url('index/index'); ?>"class="search-form">
						<input name="fname" type="text" id="keyword" class="search-text" />
						<button type="submit"class="button button-caution  button-border">搜</button>
					</form>
					<ul class="keyword">
						<li><a href="#" target="_blank">C基础开发</a></li>
						<li><a href="#" target="_blank">Java开发实战</a></li>
						<li><a href="#" target="_blank">Php开发</a></li>
						<li><a href="#" target="_blank">Node.js从深入简</a></li>
					</ul>
	
					<div class="suggestions_box" id="suggestions" style="display: none;">
						<div class="suggestions_list" id="auto_suggestions_list">&nbsp;</div>
					</div>
	
				</div>
	</div>
<!-- 购物车 -->
	<div class="shopCart" data-ectype="dorpdown" id="ECS_CARTINFO"
				data-carteveval="0" >
				<div class="shopCart-con dsc-cm">
					<a href="<?php echo url('cart/index'); ?>" "> 
							<!-- 	<span style="color: red;">我的购物车</span> -->
						<button class="button button-caution button-glow button-border">购物车</button>
					</a>
				</div>
</div>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery.-1.10.2.min.js"></script>	
<script type="text/javascript" src="/bigHomework/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery-1.10.2.animate.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/assets/font/iconfont.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/bootsnav.js"></script>
<script type="text/javascript"  src="/bigHomework/public/static/js/buttons.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery.fadethis.min.js"></script>
<script>
			$(window).fadeThis();
</script>
 <script>
     $(document).ready(function(){
        $(".dropdown-toggle").hover(function());
      });
</script>

			
			
			
			
			
		
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			

<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<link href="/bigHomework/public/static/css/orderList.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="/bigHomework/public/static/js/jquery-1.4.2.js"></script>
<style>
/*分页样式*/   
.pagination{text-align:center;margin-top:20px;margin-bottom: 20px;}  
.pagination li{margin:0px 10px; border:1px solid #e6e6e6;padding: 3px 8px;display: inline-block;}  
.pagination .active{background-color: #46A3FF;color: #fff;}  
.pagination .disabled{color:#aaa;} 
</style>

<script>
$(function(){
	$(".del").click(function(){
		var orderID = $(".del").attr("id");
		//alert(orderID);
		//$(".del").parents("div").hide();
		$.post("<?php echo url('order/delete'); ?>",{orderID:orderID},function(result){
			if(result == "success"){
				$(".del").parents("div").hide();
				window.location.href="<?php echo url('order/showorder'); ?>";
			}
		});
	})
})

</script>

</head>
<body>
<center>

    <div class="no_order_info" >
    <!-- 提示您暂时没有订单信息 -->
   <?php if($showorder == null): ?>
   	您还没有添加任何订单！
   	<?php endif; ?>
    </div>
    <!-- 分页显示记录-->
<div class="pages"><?php echo $page; ?></div>

<!-- 模版数据 -start -->
  <?php foreach($showorder as $order): ?>
	<div style="margin: 0 auto;width:999px;">
		<dl class="Order_information">
			<dt><h3>订单信息</h3>	</dt>	
			<dd style="line-height: 26px;">
				订单编号：<?php echo $order['orderID']; ?>
				<br />
				下单时间：	<?php echo $order['inputtime']; ?>
				<br /> 
				订单金额：<?php echo $order['shifu']; ?>
				<br /> 
				订单状态：<?php echo $order['status']; ?>
				<!-- 订单状态判断 ，未付款订单允许删除！-->
				<?php switch($order['status']): case "未付款": ?>
							<font color="red"></font>&nbsp;&nbsp;
							<a class="del"  href="javascript:void(0)" id="<?php echo $order['orderID']; ?>" href="<?php echo url('order/delete'); ?>?id=<?php echo $order['orderID']; ?>&money=<?php echo $order['shifu']; ?>">
							<img src="/bigHomework/public/static/image/sc.jpg" width="69" height="19"/>
						</a>
						&nbsp;
				 		<a href="<?php echo url('order/pay'); ?>?id=<?php echo $order['orderID']; ?>&money=<?php echo $order['shifu']; ?>"> 
					 		<img src="/bigHomework/public/static/image/zx.jpg" width="69" height="19">
						</a>
				<?php break; case "已发货": ?>											
						<font color="blue"></font>&nbsp;&nbsp;		
						<a href="<?php echo url('order/orderUpdate'); ?>?orderID=<?php echo $order['orderID']; ?>">确认收货</a>	
				<?php break; case "未评价": ?>											
						<font color="blue"></font>&nbsp;&nbsp;		
						<a href="<?php echo url('order/evaluate'); ?>?orderID=<?php echo $order['orderID']; ?>">去评价</a>		
				<?php break; case "已评价": break; endswitch; ?>
				<br /> 
				收货人：<?php echo $order['sname']; ?> 
				<br/> 
				收货地址：<?php echo $order['address']; ?>
				<br/> 
				支付方式：<?php echo $order['pay_with']; ?>
			</dd>
		</dl>
	
		<table width="999px" border="0" cellpadding="0"
			cellspacing="1" style="background:#d8d8d8;color:#333333">
			<tr>
				<th width="249" height="30" align="center" valign="middle" bgcolor="#f3f3f3">商品图片</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">商品名称</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">原价</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">现价</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">购买数量</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">总价</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">商品评价</th>
			</tr>
			<?php foreach($orderlists as $orderlist): foreach($orderlist as $shoplist): if(($order['orderID'] == $shoplist['orderID'])): ?>
			
			
			<tr>
				<td align="center" valign="middle" bgcolor="#FFFFFF">
				<a href="<?php echo url('showflower/flowerDetail'); ?>?bookID=<?php echo $shoplist['bookID']; ?>">
					<img src="/bigHomework/public/static/picture/<?php echo $shoplist['pictures']; ?>" border=0></a>
				</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['bname']; ?></td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['price']; ?>元</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['yourprice']; ?>元</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['num']; ?>件</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['num'] * $shoplist['yourprice']; ?>元</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF">
					<?php if(($order['status'] == '未评价')): ?>
						<a href=" <?php echo url('order/evaluate'); ?>?orderID=<?php echo $shoplist['orderID']; ?>">评价</a>
					<?php endif; ?>
				</td>
			</tr>
				
			<?php endif; endforeach; endforeach; ?>
		</table>		
		<div class="Order_price"><?php echo $order['shifu']; ?>元</div>	
	</div>

<?php endforeach; ?>
	<!-- 模版数据 -end -->
	<div class="pages"><?php echo $page; ?></div>
	</center>
</body>
</html>