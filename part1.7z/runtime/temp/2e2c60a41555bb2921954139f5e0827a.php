<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:84:"C:\Software\AppServ\www\flowerTP/application/index\view\showflower\flowerdetail.html";i:1594048673;s:24:"./public/common/top.html";i:1593876542;}*/ ?>
﻿<meta charset="utf-8">
<center>
<table width=999px border=0>
<tr>
<td rowspan=2><img src="/flowerTP/public/static/image/logo.jpg" style="width:216px; height:68px"> </td>

<td style="font-size:x-small;">

<?php echo \think\Session::get('email'); ?>欢迎光临鲜花礼品网</td>
<td style="background:url('/flowerTP/public/static/image/topxmenubg.jpg'); font-size:x-small;text-align:center;">
<a href="member.php" style="text-decoration:none;">我的帐户</a>|
<a href="<?php echo url('order/showorder'); ?>" style="text-decoration:none;">我的订单</a>|
<a href="<?php echo url('cart/index'); ?>" style="text-decoration:none;">购物车</a>|
</td>
</tr>
<tr>
<td>
<?php if(\think\Session::get('email') == ''): ?>
<a href="<?php echo url('login/login'); ?>" style="font-size:x-small;text-decoration:none;">登录</a>&nbsp;&nbsp;
<?php else: ?>
<a href="<?php echo url('login/logOut'); ?>" style="font-size:x-small;text-decoration:none;">退出</a>&nbsp;&nbsp;
<?php endif; ?>

<a href="<?php echo url('admin/adminlogin/login'); ?>" style="font-size:x-small;text-decoration:none;">后台登录</a>&nbsp;&nbsp;</td>
<td style="text-align:right;"><img src="/flowerTP/public/static/image/ttel.jpg"></td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/bg-navbox.png'); font-size: small;text-align:center; width:999px;height:40px">
 <span style=" color:White;"> |</span> &nbsp; &nbsp; &nbsp;
    <a href="<?php echo url('index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体"> 主页</span></a>
    &nbsp;&nbsp;&nbsp; <span style=" color:White;"> |</span> &nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('index/showflower'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">鲜花</span></a>
     &nbsp; &nbsp; &nbsp; <span style=" color:White;"> |</span>&nbsp;&nbsp;&nbsp;
</td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/search_bg.jpg'); font-size: small;text-align:center; width:999px;height:35px">
<span style="font-weight:bold; font-size:x-small; font-family:宋体">
</span>
</td>
</tr>
</table></center>
<meta charset="utf-8">
<head>
    <title>鲜花礼品网</title>
    <link href="/flowerTP/public/static/css/StyleIndex.css" rel="Stylesheet" type="text/css" /></head>

</head>
<center>
 <table style='width:830px;border-width:1px;border-style:dotted;align:center;'>
     <tr>
        <td rowspan=7 width=200>
         <img src="/flowerTP/public/static/picture/<?php echo $flower['pictureb']; ?>"></td>
        <td colspan=2 align=center><div style='font-weight:bold;font-size:medium;height:40px;line-height:40px;color:#000066;text-align:center;border-width:1px;  border-style:solid;border-color:red;'>
           <?php echo $flower['fname']; ?></div></td>          	
     </tr>
     <tr>
       <td width=50><font size=2>材料: </font></td>
       <td><font size=2><?php echo $flower['cailiao']; ?></font></td> 
     </tr>
     <tr>
     	<td width=50><font size=2>包装： </font></td>
     	<td><font size=2><?php echo $flower['baozhuang']; ?></font></td>
     </tr>
    <tr>
     	<td width=50><font size=2>花语： </font></td>
     	<td><font size=2><?php echo $flower['huayu']; ?></font></td>
     </tr>
     <tr>
     	<td width=50><font size=2>说明： </font></td>
     	<td><font size=2><?php echo $flower['shuoming']; ?></font></td>
     </tr>
     <tr>
     	<td colspan=2><div style='text-align:left;font-size: medium; color: #000066;'>
     	<div style='text-decoration:line-through;margin-top:8px;'>原价:￥ <?php echo $flower['price']; ?></div>
     	现价：<font size=4 color=red><b>￥ <?php echo $flower['yourprice']; ?></b></font></div>
     	</td>
     </tr>
     <tr>
     	<td colspan=2><a href='<?php echo url('cart/addCart'); ?>?flowerID=<?php echo $flower['flowerID']; ?>'>
     	<img src='/flowerTP/public/static/image/ingwc_ico.jpg' border=0></a></td>
     </tr>
     <tr><td colspan=3><img src="/flowerTP/public/static/picture/<?php echo $flower['pictured']; ?>" border=0></td></tr>
     <tr><td colspan=3><img src="/flowerTP/public/static/picture/<?php echo $flower['bzpicture']; ?>" border=0></td></tr>
     <tr><td colspan=3><img src="/flowerTP/public/static/picture/<?php echo $flower['cailiaopicture']; ?>" border=0></td></tr>
 </table>

<table style='width:830px;font-weight:bold;border-width:1px;border-style:dotted;align:center;height:40px;'>
<tr><td>用户评价</td></tr>
</table>
<!--评价循环开始 -->
<?php foreach($shoplists as $shoplist): ?>
<table style='width:830px;font-size:small;border-width:1px;border-style:solid;align:center;height:120px;'>
<tr>
<td width=130 rowspan=2><img src='/flowerTP/public/static/picture/<?php echo $flower['pictures']; ?>'><br>
<?php echo $shoplist['email']; ?>
</td>
<td>整体评价：

<?php $__FOR_START_1258__=1;$__FOR_END_1258__=$shoplist['pjstar']+1;for($i=$__FOR_START_1258__;$i < $__FOR_END_1258__;$i+=1){ ?>
<img src="/flowerTP/public/static/image/review_star_fen.gif">
<?php } $__FOR_START_25813__=$shoplist['pjstar'];$__FOR_END_25813__=5;for($i=$__FOR_START_25813__;$i < $__FOR_END_25813__;$i+=1){ ?>
<img src="/flowerTP/public/static/image/review_star_fen_gray.gif">
<?php } ?>
</td>
<td align=right>评价时间：&nbsp;&nbsp;&nbsp;IP:</td>
</tr>
<tr><td colspan=2>评价内容：</tr>
</table>
<!--评价循环结束 -->
<?php endforeach; ?>
</center>