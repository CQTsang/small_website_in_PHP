<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:71:"C:\Software\AppServ\www\flowerTP/application/index\view\cart\index.html";i:1593751832;s:24:"./public/common/top.html";i:1593876542;}*/ ?>
﻿<meta charset="utf-8">
<center>
<table width=999px border=0>
<tr>
<td rowspan=2><img src="/flowerTP/public/static/image/logo.jpg" style="width:216px; height:68px"> </td>

<td style="font-size:x-small;">

<?php echo \think\Session::get('email'); ?>欢迎光临鲜花礼品网</td>
<td style="background:url('/flowerTP/public/static/image/topxmenubg.jpg'); font-size:x-small;text-align:center;">
<a href="member.php" style="text-decoration:none;">我的帐户</a>|
<a href="<?php echo url('order/showorder'); ?>" style="text-decoration:none;">我的订单</a>|
<a href="<?php echo url('cart/index'); ?>" style="text-decoration:none;">购物车</a>|
</td>
</tr>
<tr>
<td>
<?php if(\think\Session::get('email') == ''): ?>
<a href="<?php echo url('login/login'); ?>" style="font-size:x-small;text-decoration:none;">登录</a>&nbsp;&nbsp;
<?php else: ?>
<a href="<?php echo url('login/logOut'); ?>" style="font-size:x-small;text-decoration:none;">退出</a>&nbsp;&nbsp;
<?php endif; ?>

<a href="<?php echo url('admin/adminlogin/login'); ?>" style="font-size:x-small;text-decoration:none;">后台登录</a>&nbsp;&nbsp;</td>
<td style="text-align:right;"><img src="/flowerTP/public/static/image/ttel.jpg"></td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/bg-navbox.png'); font-size: small;text-align:center; width:999px;height:40px">
 <span style=" color:White;"> |</span> &nbsp; &nbsp; &nbsp;
    <a href="<?php echo url('index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体"> 主页</span></a>
    &nbsp;&nbsp;&nbsp; <span style=" color:White;"> |</span> &nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('index/showflower'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">鲜花</span></a>
     &nbsp; &nbsp; &nbsp; <span style=" color:White;"> |</span>&nbsp;&nbsp;&nbsp;
</td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/search_bg.jpg'); font-size: small;text-align:center; width:999px;height:35px">
<span style="font-weight:bold; font-size:x-small; font-family:宋体">
</span>
</td>
</tr>
</table></center>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>购物车</title>
<script type="text/javascript" src="/flowerTP/public/static/js/jquery-1.4.2.js"></script>
<script type="text/javascript">
if(typeof(jQuery)=="undefined"){
	alert("jQuery is not imported");
}
else{
	alert("jQuery is imported!");
}

$().ready(function(){
	sum();
	total();
	chk();
	console.log('hhh');
})

function sum(){
	$('#goods tr').each(function(){
		var price = parseFloat($(this).find("td:eq(4)").text());
		var num = parseInt($(this).find("input[name='num']").val());
		$(this).find("td:eq(6)").text(price*num);
	})
}

function total(){
	var s = 0;
	$('#goods tr').each(function(){
		if($(this).find("input[type='checkbox']").attr('checked')){
			var prices = parseFloat($(this).find("td:eq(6)").text());
			s+=prices;
		}
	})
	$("#total").text(s);
}

function change(btn,o){
	var num=0;
	num = $('#'+o).val();
	var flag = 0;
	for(var i = 0;i<num.length;i++)
	{
		if((num.charCodeAt(i)>57 || num.charCodeAt(i)<48) && num.charAt(i)!=32){
			flag=1;
			break;
	}}
		if(flag==1){
			alert("数量只能是数字！");
			return false;
		}
		else{
			var tds = $(btn).parent().siblings();
			var yourprice = tds.eq(4).text();
			tds.eq(5).text(yourprice*num);
			total();
			$.get("<?php echo url('cart/updateCart'); ?>",{"cartID":o,"num":num});
		}
	}
	
function del(btn,cid){
	$(btn).parent().parent().remove();
	total();
	$.get("<?php echo url('cart/deleteCart'); ?>",{"cartID":cid});
}

function chk(){
	total();
}

</script>

</head>
<body>
<center>

<img src="/flowerTP/public/static/image/cartbg1.jpg"><br/><br/>
<form action="<?php echo url('order/order'); ?>" name="form1" method="post">
<table style="width:881px;border-width:1px; border-style:groove;font-size:x-small;">
<tr style="background:url('/flowerTP/public/static/image/cartbg.jpg'); text-align:center;font-weight:bold; border-width:1px; border-style:groove;">
<td>选择</td><td>编号</td><td>商品名称</td><td>市场价</td><td>现价</td><td>数量</td><td>金额</td><td>删除商品</td>
</tr> 

<tbody id="goods">

<?php $sum = '0'; foreach($result as $cart): $sum = $sum+ $cart['yourprice'] *  $cart['num']; ?>

<tr style='text-align:center;height:50px;line-height:50px;'>
<td><input type='checkbox' name='cartID[]'
							value='<?php echo $cart['cartID']; ?>' checked onclick="chk()"></td>
<td><?php echo $cart['cartID']; ?></td>

<td><div style='height:50px; float:left;'>
<img src='/flowerTP/public/static/picture/<?php echo $cart['pictures']; ?>' width=48 height=51 border=0></div>
<div style='height:50px; float:left;'><?php echo $cart['fname']; ?></div>
</td>

<td><?php echo $cart['price']; ?></td>
<td><?php echo $cart['yourprice']; ?></td>

<td><input type='text' id='<?php echo $cart['cartID']; ?>' size='1' value='<?php echo $cart['num']; ?>' name='num'>
<input type='button' onclick='change(this,<?php echo $cart['cartID']; ?>)' value='更新' /></td>
<td></td>
<td>
<input type="image" onclick="del(this,<?php echo $cart['cartID']; ?>);" width="41" height="20"
		src="/flowerTP/public/static/image/04shop_deleteID.gif">
</td>
</tr>
<?php endforeach; ?>
</tbody>
				<tr>
					<td colspan="6" align="right">总计:￥</td>
					<td id="total" align="right"
						style="color: red; font-size: 16px; font-bold: true;"><?php echo $sum; ?></td>
					<td>元</td>
				</tr>
 </table>
</form>

<div style="float:left;width:881;text-align:right;">
<a href="<?php echo url('index/index'); ?>"><img src="/flowerTP/public/static/image/continue.jpg" border=0></a>&nbsp;
<a href="<?php echo url('cart/clearCart'); ?>"><img src="/flowerTP/public/static/image/clearCart.jpg" border=0></a>&nbsp;
<input type='image' src='/flowerTP/public/static/image/submitOrder.jpg' onclick='javascript:form1.submit()'>

 </center>
