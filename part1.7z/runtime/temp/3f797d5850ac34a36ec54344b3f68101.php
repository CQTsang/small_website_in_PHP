<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:76:"C:\Software\AppServ\www\flowerTP/application/admin\view\order\orderlist.html";i:1594040047;s:29:"./public/common/admintop.html";i:1593959395;}*/ ?>
﻿<center>
<meta charset="utf-8">
<table width=999px border=0>
<tr>
<td rowspan=2><img src="/flowerTP/public/static/image/logo.jpg" style="width:216px; height:68px"> </td>
<td style="font-size:x-small;"</td>
<td style="background:url('/flowerTP/public/static/image/topxmenubg.jpg'); font-size:x-small;text-align:center;">

<?php if(\think\Request::instance()->session('username') != ''): ?>
<a href="<?php echo url('adminlogin/logOut'); ?>" style="text-decoration:none;">退出</a>&nbsp;&nbsp;
<?php endif; ?>
</td>
</tr>
<tr>
<td></td>
<td style="text-align:right;"><img src="/flowerTP/public/static/image/ttel.jpg"></td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/bg-navbox.png'); font-size: small;text-align:center; width:999px;height:40px">
  <span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">&nbsp; &nbsp; &nbsp;
    <a href="<?php echo url('flower/index'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">鲜花管理</span></a>
     &nbsp; &nbsp; &nbsp;|&nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('order/orderlist'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">订单管理</span></a>
     &nbsp; &nbsp; &nbsp;|&nbsp;&nbsp;&nbsp;
     <a href=""  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">评价管理</span></a>
     &nbsp; &nbsp; &nbsp;|&nbsp;&nbsp;&nbsp;
      <a href="<?php echo url('index/index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">前台主页</span></a>
    &nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">后台主页</span></a>
    &nbsp;&nbsp;&nbsp;</span>
   
</td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/search_bg.jpg'); font-size: small;text-align:center; width:999px;height:35px">

</td>
</tr>
</table></center>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<link href="/flowerTP/public/static/css/orderList.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="/flowerTP/public/static/js/jquery-1.4.2.js"></script>
	<script type="text/javascript">
	$(function(){
		$(".del").click(function(){
			if(confirm("您确定删除该订单吗？")){
			//获取订单id
				var oid = $(this).attr("id");				
				window.location.href="<?php echo url('order/orderDelete'); ?>?orderID="+oid;
			}
		});	
	});
	</script>
</head>
<body>
<center>
<?php if(empty($peisongs) || (($peisongs instanceof \think\Collection || $peisongs instanceof \think\Paginator ) && $peisongs->isEmpty())): ?>
    <div class="no_order_info" >
    		没有需要发货的订单！
    </div>
<?php endif; ?>

<!-- 模版数据 -start -->
 <?php foreach($peisongs as $order): ?>  
	
	<div style="margin: 0 auto;width:999px;">
		<dl class="Order_information">
			<dt>
				<h3>订单信息</h3>				
			</dt>
			<table  width="999px" border="0" cellpadding="0" cellspacing="1" style="border-style:groove;background:#d8d8d8;color:#333333;line-height:30px;height:30px;">
			<tr>
			<td  style="background:#f3f3d3;width:100px;">订单编号：</td><td style="background:#ffffff;"><?php echo $order['orderID']; ?></td>
			<td  style="background:#f3f3d3;width:100px;">订单状态：</td><td style="background:#ffffff;"><?php echo $order['status']; ?></td>
			</tr><tr>
					<td style="background:#f3f3d3;width:100px;">收货人：</td><td style="background:#ffffff;"> <?php echo $order['sname']; ?></td>
					<td style="background:#f3f3d3;width:100px;">订单金额：</td><td style="background:#ffffff;"><?php echo $order['shifu']; ?></td>
				</tr><tr>
				
			<td style="background:#f3f3d3;width:100px;"> 配送日期：</td>
			    <td style="background:#ffffff;"><?php echo $order['peisongday']; ?></td>	
				
				<td  style="background:#f3f3d3;width:100px;">配送时间段：</td>
				<td style="background:#ffffff;"><?php echo $order['peisongtime']; ?></td>
				</tr>
				<tr>
			<td  style="background:#f3f3d3;width:100px;">卡片署名：</td><td style="background:#ffffff;"><?php echo $order['buy_name']; ?></td>
				<td style="background:#f3f3d3;width:100px;">下单时间：</td><td style="background:#ffffff;"><?php echo $order['inputtime']; ?></td>	
				</tr><tr>
				<td  style="background:#f3f3d3;width:100px;">卡片留言：</td><td colspan="3" style="background:#ffffff;"><?php echo $order['message']; ?></td>	
				
				</tr><tr>
				<td  style="background:#f3f3d3;width:100px;">收货地址：</td><td colspan="3" style="background:#ffffff;"><?php echo $order['address']; ?></td>
				</tr><tr>
				<td  style="background:#f3f3d3;width:100px;">收货人电话：</td><td colspan="3" style="background:#ffffff;"><?php echo $order['mobile']; ?></td>
				</tr></table>
				
			<div style="height:40px;font-size:22px;text-align:center;background:#cdcd4b;bold:true;" >
			<form action="<?php echo url('order/send'); ?>" method="post" name="f">
				快递单号：<input type="text" name="kddh" value="123123">
				<input type="hidden" name="orderID" value="<?php echo $order['orderID']; ?>">
				<input type="submit" value="发货" name="sub">
			</form>	</div>
		</dl>
			
		<table width="999px" border="0" cellpadding="0"
			cellspacing="1" style="background:#d8d8d8;color:#333333">
			<tr>
				<th width="249" height="30" align="center" valign="middle" bgcolor="#f3f3f3">商品图片</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">商品名称</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">原价</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">现价</th>
				<th width="100" align="center" valign="middle" bgcolor="#f3f3f3">购买数量</th>
				
			</tr>
			
			<?php foreach($orderlists as $shoplists): foreach($shoplists as $shoplist): if(($order['orderID'] == $shoplist['orderID'])): ?>
			<tr>
				<td align="center" valign="middle" bgcolor="#FFFFFF">
				<a href="<?php echo url('showflower/flowerDetail'); ?>">
					<img src="/flowerTP/public/static/picture/<?php echo $shoplist['pictures']; ?>" border=0></a>
				</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['fname']; ?></td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['price']; ?>元</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['yourprice']; ?>元</td>
				<td align="center" valign="middle" bgcolor="#FFFFFF"><?php echo $shoplist['num']; ?>件</td>
			</tr>
				<?php endif; endforeach; endforeach; ?>
		</table>		
	</div>
	<?php endforeach; ?>
	<!-- 模版数据 -end -->
	</center>
</body>
</html>