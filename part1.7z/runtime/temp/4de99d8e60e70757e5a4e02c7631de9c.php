<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:72:"C:\Software\AppServ\www\flowerTP/application/index\view\index\index.html";i:1593661855;s:24:"./public/common/top.html";i:1593876542;s:27:"./public/common/bottom.html";i:1592887945;}*/ ?>
<meta charset="utf-8">
<center>
<table width=999px border=0>
<tr>
<td rowspan=2><img src="/flowerTP/public/static/image/logo.jpg" style="width:216px; height:68px"> </td>

<td style="font-size:x-small;">

<?php echo \think\Session::get('email'); ?>欢迎光临鲜花礼品网</td>
<td style="background:url('/flowerTP/public/static/image/topxmenubg.jpg'); font-size:x-small;text-align:center;">
<a href="member.php" style="text-decoration:none;">我的帐户</a>|
<a href="<?php echo url('order/showorder'); ?>" style="text-decoration:none;">我的订单</a>|
<a href="<?php echo url('cart/index'); ?>" style="text-decoration:none;">购物车</a>|
</td>
</tr>
<tr>
<td>
<?php if(\think\Session::get('email') == ''): ?>
<a href="<?php echo url('login/login'); ?>" style="font-size:x-small;text-decoration:none;">登录</a>&nbsp;&nbsp;
<?php else: ?>
<a href="<?php echo url('login/logOut'); ?>" style="font-size:x-small;text-decoration:none;">退出</a>&nbsp;&nbsp;
<?php endif; ?>

<a href="<?php echo url('admin/adminlogin/login'); ?>" style="font-size:x-small;text-decoration:none;">后台登录</a>&nbsp;&nbsp;</td>
<td style="text-align:right;"><img src="/flowerTP/public/static/image/ttel.jpg"></td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/bg-navbox.png'); font-size: small;text-align:center; width:999px;height:40px">
 <span style=" color:White;"> |</span> &nbsp; &nbsp; &nbsp;
    <a href="<?php echo url('index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体"> 主页</span></a>
    &nbsp;&nbsp;&nbsp; <span style=" color:White;"> |</span> &nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('index/showflower'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">鲜花</span></a>
     &nbsp; &nbsp; &nbsp; <span style=" color:White;"> |</span>&nbsp;&nbsp;&nbsp;
</td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/search_bg.jpg'); font-size: small;text-align:center; width:999px;height:35px">
<span style="font-weight:bold; font-size:x-small; font-family:宋体">
</span>
</td>
</tr>
</table></center>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<link href="/flowerTP/public/static/css/prodList.css" rel="stylesheet" type="text/css">
</head>
<body>
<center>
<div id="content">

		<div id="search_div">
			<form method="post" action="<?php echo url('index/index'); ?>">
				<span class="input_span">商品名：<input type="text" name="fname"/></span>
				<span class="input_span">商品种类：
				<select name="fclass">
				<Option value="">不限</option>
				<?php foreach($fclasses as $fclass): ?>
				<Option value = "<?php echo $fclass['fclass']; ?>"><?php echo $fclass['fclass']; ?></Option>
				<?php endforeach; ?>
				</select>
				</span>
				<span class="input_span">商品价格区间：<input type="text" name="minprice" value="0"/> - <input type="text" name="maxprice"  value="1000"/></span>
				<input type="submit" value="查 询">
			</form>
		</div>


	<div id="prod_content">
	
	<?php foreach($flowers as $flower): ?>
	
	
		<div class="prod_div">
			<a href="/flowerTP/index.php/index/showflower/flowerdetail.html?flowerID=<?php echo $flower['flowerID']; ?>">
				<img src="/flowerTP/public/static/picture/<?php echo $flower['picturem']; ?>" border="0"/>
			</a>
				<div id="prod_name_div"><?php echo $flower['fname']; ?></div>
				<div id="prod_price_div">￥<?php echo $flower['yourprice']; ?>元</div>
				<div>
					<div id="gotocart_div">
					<a href='<?php echo url('cart/addCart'); ?>?flowerID=<?php echo $flower['flowerID']; ?>'>
					加入购物车
					</a>
					</div>					
					<div id="say_div"><?php echo $flower['SelledNum']; ?>人购买</div>					
				</div>
			</div>
<?php endforeach; ?>
			<div style="clear: both"></div>
	</div>
</div>
</div>
	<div id="footer">
Copyright © 2016, flowersforjx.com, All Rights Reserved 粤华师备 20132003040号 粤ICP备 123456号
</div>
</center>
</body>
</html>