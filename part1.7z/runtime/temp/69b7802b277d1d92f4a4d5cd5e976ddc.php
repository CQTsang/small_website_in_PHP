<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:80:"C:\Software\AppServ\www\flowerTP/application/admin\view\flower\flowerupdate.html";i:1594048890;s:29:"./public/common/admintop.html";i:1593959395;}*/ ?>
﻿<center>
<meta charset="utf-8">
<table width=999px border=0>
<tr>
<td rowspan=2><img src="/flowerTP/public/static/image/logo.jpg" style="width:216px; height:68px"> </td>
<td style="font-size:x-small;"</td>
<td style="background:url('/flowerTP/public/static/image/topxmenubg.jpg'); font-size:x-small;text-align:center;">

<?php if(\think\Request::instance()->session('username') != ''): ?>
<a href="<?php echo url('adminlogin/logOut'); ?>" style="text-decoration:none;">退出</a>&nbsp;&nbsp;
<?php endif; ?>
</td>
</tr>
<tr>
<td></td>
<td style="text-align:right;"><img src="/flowerTP/public/static/image/ttel.jpg"></td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/bg-navbox.png'); font-size: small;text-align:center; width:999px;height:40px">
  <span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">&nbsp; &nbsp; &nbsp;
    <a href="<?php echo url('flower/index'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">鲜花管理</span></a>
     &nbsp; &nbsp; &nbsp;|&nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('order/orderlist'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">订单管理</span></a>
     &nbsp; &nbsp; &nbsp;|&nbsp;&nbsp;&nbsp;
     <a href=""  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">评价管理</span></a>
     &nbsp; &nbsp; &nbsp;|&nbsp;&nbsp;&nbsp;
      <a href="<?php echo url('index/index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">前台主页</span></a>
    &nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">后台主页</span></a>
    &nbsp;&nbsp;&nbsp;</span>
   
</td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/search_bg.jpg'); font-size: small;text-align:center; width:999px;height:35px">

</td>
</tr>
</table></center>
<meta charset="utf-8">
<center>
<br><br>
 <FORM action="<?php echo url('flower/updateFlower'); ?>" method="post" enctype="multipart/form-data">
   <table style="width:550px;border-width:2px;border-style:dotted;">
   <tr>
   <td colspan=2 style="background:url('image/ico_60.jpg'); text-align:center; width:650px;">
   <font size=4>鲜花修改</font>&nbsp;&nbsp;<a href="<?php echo url('flower/index'); ?>">返回</a></td>   
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>编号：</font></td>   
   <td><input type=text name="flowerID" SIZE="18" readonly="true" value="<?php echo $flower['flowerID']; ?>"></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>名称：</font></td>   
   <td><input type=text name="fname" SIZE=50 value="<?php echo $flower['fname']; ?>"></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>类别：</font></td>   
   <td><Select name="myclass" >
                     <Option value="鲜花" selected>鲜花
                     <Option value="蛋糕">蛋糕
                     <Option value="礼篮">礼篮
                     <Option value="果篮">果篮
                     <Option value="公仔">公仔
                   </Select> 
   </td>  
   </tr> 
   <tr>
   <td style="text-align:right"><font size=2>用途：</font></td>   
   <td><Select name="fclass" >
                     <Option value="爱情鲜花">爱情鲜花
                     <Option value="友情鲜花">友情鲜花
                     <Option value="生日鲜花">生日鲜花
                     <Option value="问候长辈">问候 长辈
                     <Option value="回报老师">回报老师
                     <Option value="祝福庆贺">祝福庆贺
                     <Option value="婚庆鲜花">婚庆鲜花
                     <Option value="探病慰问">探病慰问
                     <Option value="生子祝贺">生子祝贺
                     <Option value="道歉鲜花">道歉鲜花
                     <Option value="家居鲜花">家居鲜花
                     <Option value="丧葬哀思">丧葬哀思
                     <Option value="开业乔迁">开业乔迁
                     <Option value="商务礼仪">商务礼仪
                   </Select> 
   </td>  
   </tr>
    <tr>
   <td style="text-align:right"><font size=2>主材料：</font></td>   
   <td><Select name="fclass1" >
                     <Option value="玫瑰">玫瑰
                     <Option value="康乃馨">康乃馨
                     <Option value="郁金香">郁金香
                     <Option value="百合">百合
                     <Option value="扶郎">扶郎
                     <Option value="马蹄莲">马蹄莲
                     <Option value="向日葵">向日葵
                     <Option value="蓝色妖姬">蓝色妖姬
                   </Select> 
   </td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>材料：</font></td>   
   <td><TextArea name="cailiao" Rows="4" Cols="40"><?php echo $flower['cailiao']; ?></TextArea></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>包装：</font></td>   
   <td><TextArea name="baozhuang" Rows="4" Cols="40"><?php echo $flower['baozhuang']; ?></TextArea></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>花语：</font></td>   
   <td><TextArea name="huayu" Rows="5" Cols="40" ><?php echo $flower['huayu']; ?></TextArea></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>说明：</font></td>   
   <td><input type=text name="shuoming" SIZE=50 value="<?php echo $flower['shuoming']; ?>"></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>市场价：</font></td>   
   <td><input type=text name="price" SIZE=18 value="<?php echo $flower['price']; ?>"></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>现价：</font></td>   
   <td><input type=text name="yourprice" SIZE=18 value="<?php echo $flower['yourprice']; ?>"></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>最小图片：</font></td>
   <td><input type="file" name="pictures" size="24">
   <img src="/flowerTP/public/static/picture/<?php echo $flower['pictures']; ?>"></td>
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>图片：</font></td>
   <td><input type="file" name="picturem" size="24"> 
   <a href="/flowerTP/public/static/picture/<?php echo $flower['picturem']; ?>">
   <img src="/flowerTP/public/static/picture/<?php echo $flower['picturem']; ?>" width="80" height="80" border="0"> </a></td>
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>大图片：</font></td>
   <td><input type="file" name="pictureb" size="24">
   <a href="/flowerTP/public/static/picture/<?php echo $flower['pictureb']; ?>">
   <img src="/flowerTP/public/static/picture/<?php echo $flower['pictureb']; ?>" width="80" height="80" border="0"> </a></td>
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>详细介绍：</font></td>
   <td><input type="file" name="pictured" size="24">
   <a href="/flowerTP/public/static/picture/<?php echo $flower['pictured']; ?>">
   <img src="/flowerTP/public/static/picture/<?php echo $flower['pictured']; ?>" width="100" height="80" border="0"> </a></td>
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>材料图片：</font></td>
   <td><input type="file" name="cailiaopicture" size="24"> 
   <a href="/flowerTP/public/static/picture/<?php echo $flower['cailiaopicture']; ?>">
   <img src="/flowerTP/public/static/picture/<?php echo $flower['cailiaopicture']; ?>" width="100" height="80" border="0"> </a></td>
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>包装图片：</font></td>
   <td><input type="file" name="bzpicture" size="24">
   <a href="/flowerTP/public/static/picture/<?php echo $flower['bzpicture']; ?>">
   <img src="/flowerTP/public/static/picture/<?php echo $flower['bzpicture']; ?>" width="100" height="80" border="0"> </a></td>
   </tr>
   <tr>
   <tr>
   <td style="text-align:right"><font size=2>是否特价：</font></td>   
   <td><Select name="tejia" >
                     <Option value="是" selected>是
                     <Option value="否">否
                   </Select> 
   </td>  
   </tr>  
   <tr>
   <td colspan=2 style="text-align:center"><INPUT type="submit" name="s" value="提交"></td></tr>
   </table>
   </FORM>
</center>