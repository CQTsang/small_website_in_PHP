<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:80:"C:\Software\AppServ\www\bigHomework/application/admin\view\flower\floweradd.html";i:1594209371;s:30:"./public/common/admintop2.html";i:1594264555;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN" style="width: 100%;">
<head>
	<meta charset="utf-8">
	<!--设备适配-->
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0.5, maximum-scale=2.0, user-scalable=no">
	<!--适配ie-->
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>书虫网</title>
	 <!-- Favicon -->
    <link rel="icon" href="/bigHomework/public/static/assets/images/favicon.ico" type="text/css">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="/bigHomework/public/static/css/bootstrap.min.css" type="text/css">
	<!-- animate CSS -->
	<link rel="stylesheet" href="/bigHomework/public/static/css/animate.min.css" type="text/css">
	<!-- MYCSS -->
	<link rel="stylesheet" type="text/css" href="/bigHomework/public/static/css/index.css" type="text/css">
	<!-- icon -->
	<link rel="stylesheet" href="/bigHomework/public/static/assets/font/iconfont.css" type="text/css"> 
	<!-- bootsnav -->
	<link rel="stylesheet" href="/bigHomework/public/static/css/bootsnav.css"  type="text/css"/>
	<link rel="stylesheet" href="/bigHomework/public/static/assets/font-awesome-4.7.0/css/font-awesome.css"  type="text/css"/>
	<link rel="stylesheet" href="/bigHomework/public/static/css/buttons.min.css" type="text/css"/>
	<base target="_self">

	
	   
</head>
<body style="width: 100%;">


<!--main header navbar-->

	<div class="container">
		
			<div class="row">		
			<div class="col-md-12">		
			<nav class="navbar navbar-default navbar-mobile bootsnav on">		
			<div class="navbar-header">	
			<a class="navbar-brand" href="#">
				<span class="bz">书虫网</span>
			</a>
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">		
			<i class="fa fa-bars"></i>		
			</button>		
	</div>	
	<div class="collapse navbar-collapse" id="navbar-menu">		
			<ul class="nav navbar-nav navbar-left" data-in="fadeInDown" data-out="fadeOutUp">
				<li><a href="<?php echo url('flower/index'); ?>">图书管理</a></li>
				<li><a href="<?php echo url('order/orderlist'); ?>">订单管理</a></li>
				<li><a href="<?php echo url('order/orderPJcheck'); ?>">评价管理</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">

				<?php if(\think\Request::instance()->session('username') != ''): ?>
				<li><a href="<?php echo url('adminlogin/logOut'); ?>">退出</a></li>
				<?php else: ?>
				<li><a href="<?php echo url('adminlogin/login'); ?>">后台登录</a></li>
				<?php endif; ?>
				
				
			</ul>
	
			</div>
		</nav>
	</div>
	</div>
	</div>

	<!-- 搜索 -->
	<div class="dsc-search">
				<div class="form">
					<form id="searchForm" method="get"
						action="/index/goods/list"class="search-form">
						<input name="goodsName" type="text" id="keyword" class="search-text" />
						<button type="submit"class="button button-caution  button-border" >搜</button>
					</form>	
					<div class="suggestions_box" id="suggestions" style="display: none;">
						<div class="suggestions_list" id="auto_suggestions_list">&nbsp;</div>
					</div>
	
				</div>
	</div>
<!-- 购物车 -->

<script type="text/javascript" src="/bigHomework/public/static/js/jquery.-1.10.2.min.js"></script>	
<script type="text/javascript" src="/bigHomework/public/static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery-1.10.2.animate.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/assets/font/iconfont.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/bootsnav.js"></script>
<script type="text/javascript"  src="/bigHomework/public/static/js/buttons.js"></script>
<script type="text/javascript" src="/bigHomework/public/static/js/jquery.fadethis.min.js"></script>
<script>
			$(window).fadeThis();
</script>
 <script>
     $(document).ready(function(){
        $(".dropdown-toggle").hover(function());
      });
</script>

			
			
			
			
			
		
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			

<meta charset="utf-8">
<center>
<br><br>

 <FORM action="<?php echo url('flower/addFlower'); ?>" method="post" enctype="multipart/form-data">
   <table style="width:550px;border-width:2px;border-style:dotted;">
   <tr>
   <td colspan=2 style="background:url('image/ico_60.jpg'); text-align:center; width:650px;">
   <font size=4>添加图书</font>&nbsp;&nbsp;<a href="<?php echo url('flower/index'); ?>">返回</a></td>   
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>编号：</font></td>   
   <td><input type=text name="flowerID" SIZE=18></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>名称：</font></td>   
   <td><input type=text name="fname" SIZE=18></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>作者：</font></td>   
   <td>
   <input type=text name="myclass" SIZE=18></input>
   </td>  
   </tr> 
   <tr>
   <td style="text-align:right"><font size=2>出版商：</font></td>   
   <td>
<input type=text name="fclass"  SIZE=18></input>
   </td>  
   </tr>
    <tr>
   <td style="text-align:right"><font size=2>种类：</font></td>   
   <td>
 <input type=text name="fclass1" SIZE=18></input>                
   </td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>开本：</font></td>   
   <td><input type=text name="cailiao" SIZE=18></input></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>包装：</font></td>   
   <td>
   <Select name="baozhuang" >
                     <Option value="平装">平装
                     <Option value="精装">精装
  </Select> 
  </td>
  </tr>
   <tr>
   <td style="text-align:right"><font size=2>评价：</font></td>   
   <td><TextArea name="huayu" Rows="3" Cols="40" ></TextArea></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>内容说明：</font></td>   
   <td><TextArea name="shuoming" Rows="3" Cols="40"></TextArea></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>市场价：</font></td>   
   <td><input type=text name="price" SIZE=18></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>现价：</font></td>   
   <td><input type=text name="yourprice" SIZE=18></td>  
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>最小图片：</font></td>
   <td><input type="file" name="pictures" size="24"> </td>
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>图片：</font></td>
   <td><input type="file" name="picturem" size="24"> </td>
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>大图片：</font></td>
   <td><input type="file" name="pictureb" size="24"> </td>
   </tr>
   <tr>
   <td style="text-align:right"><font size=2>详细介绍：</font></td>
   <td><input type="file" name="pictured" size="24"> </td>
   </tr>

   
   <tr>
   <tr>
   <td style="text-align:right"><font size=2>是否特价：</font></td>   
   <td><Select name="tejia" >
                     <Option value="是" selected>是
                     <Option value="否">否
                   </Select> 
   </td>  
   </tr>  
   <tr>
   <td colspan=2 style="text-align:center"><INPUT type="submit" name="s" value="提交"></td></tr>
   </table>
   </FORM>
</center>