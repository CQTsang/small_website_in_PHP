<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:73:"C:\Software\AppServ\www\flowerTP/application/admin\view\flower\index.html";i:1594048890;s:29:"./public/common/admintop.html";i:1593959395;}*/ ?>
<body>
<center>
﻿<center>
<meta charset="utf-8">
<table width=999px border=0>
<tr>
<td rowspan=2><img src="/flowerTP/public/static/image/logo.jpg" style="width:216px; height:68px"> </td>
<td style="font-size:x-small;"</td>
<td style="background:url('/flowerTP/public/static/image/topxmenubg.jpg'); font-size:x-small;text-align:center;">

<?php if(\think\Request::instance()->session('username') != ''): ?>
<a href="<?php echo url('adminlogin/logOut'); ?>" style="text-decoration:none;">退出</a>&nbsp;&nbsp;
<?php endif; ?>
</td>
</tr>
<tr>
<td></td>
<td style="text-align:right;"><img src="/flowerTP/public/static/image/ttel.jpg"></td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/bg-navbox.png'); font-size: small;text-align:center; width:999px;height:40px">
  <span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">&nbsp; &nbsp; &nbsp;
    <a href="<?php echo url('flower/index'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">鲜花管理</span></a>
     &nbsp; &nbsp; &nbsp;|&nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('order/orderlist'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">订单管理</span></a>
     &nbsp; &nbsp; &nbsp;|&nbsp;&nbsp;&nbsp;
     <a href=""  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">评价管理</span></a>
     &nbsp; &nbsp; &nbsp;|&nbsp;&nbsp;&nbsp;
      <a href="<?php echo url('index/index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">前台主页</span></a>
    &nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">后台主页</span></a>
    &nbsp;&nbsp;&nbsp;</span>
   
</td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/search_bg.jpg'); font-size: small;text-align:center; width:999px;height:35px">

</td>
</tr>
</table></center>
<meta charset="utf-8">
<a href="<?php echo url('flower/floweradd'); ?>">添加鲜花</a>
<table width="999px" border="0" cellpadding="0"
			cellspacing="1" style="background:#d8d8d8;color:#333333">
			<tr><th width="100px" height="30" align="center" valign="middle">商品编号</th>
				<th width="150px" align="center" valign="middle">商品图片</th>
				<th width="110px" height="30" align="center" valign="middle">商品名称</th>
				<th width="100px" align="center" valign="middle" >原价</th>
				<th width="100px" align="center" valign="middle">现价</th>
				<th width="100px" align="center" valign="middle" >销售数量</th>				
				<th width="100px" align="center" valign="middle">操作</th>				
			
			</tr>
			<?php foreach($flowers as $flower): ?>
			
			<tr><td valign="middle" bgcolor="#FFFFFF"><?php echo $flower['flowerID']; ?></td>
				<td align="center" valign="middle" bgcolor="#FFFFFF">
				<a href="<?php echo url('flower/flowerDetail'); ?>?flowerID=<?php echo $flower['flowerID']; ?>">
					<img src="/flowerTP/public/static/picture/<?php echo $flower['picturem']; ?>" width="60" heigth="60" border=0></a>
				</td>
				<td valign="middle" bgcolor="#FFFFFF"><?php echo $flower['fname']; ?></td>
				<td valign="middle" bgcolor="#FFFFFF"><?php echo $flower['price']; ?>元</td>
				<td valign="middle" bgcolor="#FFFFFF"><?php echo $flower['yourprice']; ?>元</td>
				<td valign="middle" bgcolor="#FFFFFF"><?php echo $flower['SelledNum']; ?>件</td>
				<td valign="middle"  align="center"  bgcolor="#FFFFFF">
				<a href="<?php echo url('flower/flowerupdate'); ?>?flowerID=<?php echo $flower['flowerID']; ?>">修改</a>
				<a href="<?php echo url('flower/flowerDelete'); ?>?flowerID=<?php echo $flower['flowerID']; ?>">删除</a>
				</td>
			</tr>
			<?php endforeach; ?>
			</table>
</center></body>