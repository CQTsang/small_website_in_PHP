<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:72:"C:\Software\AppServ\www\flowerTP/application/index\view\order\order.html";i:1593952604;s:24:"./public/common/top.html";i:1593876542;s:27:"./public/common/bottom.html";i:1592887945;}*/ ?>
<meta charset="utf-8">
<center>
<table width=999px border=0>
<tr>
<td rowspan=2><img src="/flowerTP/public/static/image/logo.jpg" style="width:216px; height:68px"> </td>

<td style="font-size:x-small;">

<?php echo \think\Session::get('email'); ?>欢迎光临鲜花礼品网</td>
<td style="background:url('/flowerTP/public/static/image/topxmenubg.jpg'); font-size:x-small;text-align:center;">
<a href="member.php" style="text-decoration:none;">我的帐户</a>|
<a href="<?php echo url('order/showorder'); ?>" style="text-decoration:none;">我的订单</a>|
<a href="<?php echo url('cart/index'); ?>" style="text-decoration:none;">购物车</a>|
</td>
</tr>
<tr>
<td>
<?php if(\think\Session::get('email') == ''): ?>
<a href="<?php echo url('login/login'); ?>" style="font-size:x-small;text-decoration:none;">登录</a>&nbsp;&nbsp;
<?php else: ?>
<a href="<?php echo url('login/logOut'); ?>" style="font-size:x-small;text-decoration:none;">退出</a>&nbsp;&nbsp;
<?php endif; ?>

<a href="<?php echo url('admin/adminlogin/login'); ?>" style="font-size:x-small;text-decoration:none;">后台登录</a>&nbsp;&nbsp;</td>
<td style="text-align:right;"><img src="/flowerTP/public/static/image/ttel.jpg"></td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/bg-navbox.png'); font-size: small;text-align:center; width:999px;height:40px">
 <span style=" color:White;"> |</span> &nbsp; &nbsp; &nbsp;
    <a href="<?php echo url('index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体"> 主页</span></a>
    &nbsp;&nbsp;&nbsp; <span style=" color:White;"> |</span> &nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('index/showflower'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">鲜花</span></a>
     &nbsp; &nbsp; &nbsp; <span style=" color:White;"> |</span>&nbsp;&nbsp;&nbsp;
</td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/search_bg.jpg'); font-size: small;text-align:center; width:999px;height:35px">
<span style="font-weight:bold; font-size:x-small; font-family:宋体">
</span>
</td>
</tr>
</table></center>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<title>填写订单</title>
	<link rel="stylesheet" href="/flowerTP/public/static/css/basic.css" >
	<link rel="stylesheet" href="/flowerTP/public/static/css/order.css" >
	<link rel="stylesheet" href="/flowerTP/public/static/font-awesome-4.5.0/css/font-awesome.min.css" >
	<link rel="icon" href="/flowerTP/public/static/image/icon.png" type="image/png">
	<script src="/flowerTP/public/static/js/jquery-1.8.3.min.js"></script>	
<script>
//文档就绪事件开始
$(function(){
		// 设置收货人
		var name = $("#selectedname").text();
		var address = $("#selectedaddress").text();
		var phone = $("#selectedphone").text();
		var custID = $("#selectedcustID").text();
		
		$("input[name=custID]").val(custID);	
		
		$("#send-to").text("配送至："+address);
		$("#send-for").text("收货人："+name+" "+phone);
		
		
		// 选择配送时段和支付方式时
		$(".time").click(function(){
			$(this).parent().children(".selected").removeClass("selected").addClass("select");
			$(this).removeClass("select").addClass("selected");
			$(this).parent().children("input:hidden").val($(this).text());			
		});
		
		// 切换送花对象时
		$(".words").hide();
		$(".words:first").show();
		$(".for-who").click(function(){
			var index=$(".send-word>div").index($(this));
			$(".words").hide();
			$(".words").eq(index).show();
			$(".for-who").removeClass("who-selected");
			$(this).addClass("who-selected");
		});
		// 当快速选择赠言时
		$(".word-select").click(function(){
			var len=$(this).text().length;
			var str=$(this).text().substr(2,len-2);
			
			$("textarea[name=message]").val(str);
			$(".type-word").text(202-len);
		});
		//当赠言超过200字时
		$("textarea[name=message]").keyup(function(e){
			var len=$(this).val().length;
			var left=200-len;
			// console.log(len);
			$(".type-word").text(left);
			if(left<=0){
				$(this).val($(this).val().substr(0,199));
			}
		});
		//关闭添加收件人面板
		$(".close-panel").click(function(){
			$("#add-panel").hide();
			$("#hgb").fadeOut("fast");
		});
		
		//点击提交
		$("#submit").click(function(event){
			var custID=$("input[name='custID']").val();
			var total = $(".total-price").text();
			var date=$("input[name=date]").val();
			var time=$("input[name=time]").val();
			var message=$("#message").val();
			var buy_name=$(".buy-name").text();
			var pay_with=$("input[name=pay-with]").val();
			
			$.post('<?php echo url('order/addOrder'); ?>',{
				custID:custID, 
				shifu:total,
				date:date,
				time:time,
				message:message,
				buy_name:buy_name, 
				pay_with:pay_with
			},function(data){
				if(data=="success"){
					window.location.href="<?php echo url('order/showorder'); ?>";	
				}				
			});
		});	
		
});
//文档就绪事件结束	

// 选择收货人
function Select(obj){
	var name=$(obj).text();
	var address=$(obj).parent().find(".address").text();
	var phone=$(obj).parent().find(".phone").text();
	var custID=$(obj).parent().find(".custID").text();
	$(".select-name").removeClass("selected").addClass("select");
	$(obj).removeClass("select").addClass("selected");
	
	$("input[name=custID]").val(custID);
	
	$("#send-to").text("配送至："+address);
	$("#send-for").text("收货人："+name+" "+phone);
}

//对收货人进行操作
function ConsigneeOper(member,operation){
	if("member" == member && operation == "add"){
		$("#edit-btn").hide();
		$("#add-panel").show().css({"center":($(window).width()/2-200)});
		$("#add-btn").show();
	//	$("#hgb").fadeIn("fast").css({"height":$(window).height(),"top":0});
		$(".edit-panel>input").val("");
	}else if(operation == "edit"){
		$("#add-btn").hide();
		$("#add-panel").show().css({"center":($(window).width()/2-200)});
		$("#hgb").fadeIn("fast").css({"height":$(window).height(),"top":0});
		$("#edit-btn").show();
		$("#edit-btn").attr('onclick','javascript:SaveConsignee("'+member+'","edit")');
		var editId="#scn"+member;
		var editName=$(editId).find(".select-name").text();
		var address=$(editId).find(".address").text().split(" ");
		
		var editProvince=address[0];
		var editCity=address[1];
		var editAddr=address[2];
		if(address.length==1){
			editProvince="";
			editAddr=address[0];
		}
		var editPhone=$(editId).find(".phone").text();
		$("#addName").val(editName);
		$("#addPhone").val(editPhone);
		$("#addProvince").val(editProvince);
		$("#addCity").val(editCity);
		$("#addAddr").val(editAddr);
		
	}else if(operation == "default"){
		var original=$(".default-address").parent();
		var originalID=$(original).attr('id');	
		
		var idLen=originalID.length;		
		var defaultId="#scn"+member;
		
		originalID=originalID.substr(3,idLen);
		// ajax设置默认
		$.post("<?php echo url('customer/setDefault'); ?>",{custID:member,originalID:originalID});
		// 新增默认		
	//	alert(defaultId);
		$(defaultId).find(".delete").remove();
		$(defaultId).find(".set-default").remove();
		$(defaultId).append('<span class="default-address">默认地址</span>');
		// 删掉原默认
		$(original).find(".default-address").remove();
		$(original).find(".edit").remove();
		$(original).append('<a class="delete" href="javascript:ConsigneeOper(\''+originalID+'\',\'delete\')">删除</a>'
					+'<a class="edit" href="javascript:ConsigneeOper(\''+originalID+'\',\'edit\')">编辑</a>'
					+'<a class="set-default" href="javascript:ConsigneeOper(\''+originalID+'\',\'default\')">设为默认地址</a>');
		

	}else if(operation=="delete"){
		// ajax删除服务器数据
		var deleteId="#scn"+member;
		$.post("<?php echo url('customer/deleteCustomer'); ?>",{custID:member},function(result){
			if(result=='success'){
				$(deleteId).hide();
			}
		});
	}
	
}
// 保存收货人信息SaveConsignee
function SaveConsignee(member,operation){
	var addName=$("#addName").val();
	var addPhone=$("#addPhone").val();
	var addProvince=$("#addProvince").val();
	var addCity=$("#addCity").val();
	var addAddr=$("#addAddr").val();
	var addBelongEmail =$("#buy-email").val();
	var address=addProvince+" "+addCity+" "+addAddr;
	switch(operation){
		case 'add':	
			// ajax添加数据
			$("#hgb").fadeOut("fast");
			$("#add-panel").hide();
			$.post("<?php echo url('customer/addCustomer'); ?>",{addName:addName,addPhone:addPhone,address:address,buyemail:addBelongEmail},function(data){					
				alert(data);
					$(".select-name").removeClass("selected").addClass("select");
					$("#select-consignee").append(
						'<div class="bar-info"><div class="selected select-name" onclick="Select(this)">'
						+addName+'</div><span class="name">'+addName+'</span><span class="address">'+address
						+'</span><span class="phone">'+addPhone+'</span>');
						
//						+'<a class="delete" href="javascript:ConsigneeOper(\''+data+'\',\'delete\')">删除</a>'
//						+'<a class="edit" href="javascript:ConsigneeOper(\''+data+'\',\'edit\')">编辑</a>'
//						+'<a class="set-default" href="javascript:ConsigneeOper(\''+data+'\',\'default\')">设为默认地址</a></div>');					
					$("input[name=custID]").val(data);		
					$("#send-to").text("配送至："+address);
					$("#send-for").text("收货人："+addName+" "+addPhone);
			});
			break;
		case 'edit':
			//ajax更新服务器数据
			$("#hgb").fadeOut("fast");
			$("#add-panel").hide();
			var editId="#scn"+member;
			$.post("<?php echo url('customer/editCustomer'); ?>",{addName:addName,addPhone:addPhone,address:address,custID:member},function(data){
				// console.log(data);
				if(data=='success'){
					$(editId).find(".select-name").text(addName);
					$(editId).find(".name").text(addName);
					$(editId).find(".address").text(address);
					$(editId).find(".phone").text(addPhone);
				}
			});
			break;
	}
}
//保存订购人
function AddBuyer(){
	var name=$("#buy-name").val();
	var phone=$("#buy-phone").val();
	var email=$("#buy-email").val();
	// ajax更新服务器数据
	$("#add-buyer").parent().text("").append('<span class="buy-name">'+name
		+'</span><span class="buy-phone">'+phone+'</span><span class="buy-email">'+email+'</span>'
				+'<a href="javascript:EditBuyer()" class="edit-buy">编辑</a>');
	$.post("<?php echo url('member/editMember'); ?>",{name:name,phone:phone});
	
}
// 修改订购人
function EditBuyer(){
	var name=$(".buy-name").text();
	var phone=$(".buy-phone").text();
	var email=$(".buy-email").text();
	// ajax更新服务器数据
	$(".edit-buy").parent().text("").append('<input id="buy-name" type="text" placeholder="您的姓名">'
				+'<input id="buy-phone" type="text" placeholder="手机号码或电话">'
				+'<input id="buy-email" class="disabled" type="text" value="hhccrr@foxmail.com" disabled="disabled">'
				+'<button onclick="AddBuyer()" id="add-buyer">确定</button>');
	$("#buy-name").val(name);
	$("#buy-phone").val(phone);
	$("#buy-email").val(email);
	$.post("<?php echo url('member/editMember'); ?>",{name:name,phone:phone});
}
</script>
</head>
<body>
	<div id="section">
		<div id="center">
		<div class="edit-order">
			<div class="order-info">
				<div class="info-bar">
					<span>填写订单信息</span>
				</div>
			</div>
			<div id="select-consignee" class="order-bar">
				<div class="bar-title">
					<span>收货人信息</span>
					<a href="javascript:ConsigneeOper('member','add')">新增收货人+</a>
				</div>
				
				<input type="hidden" name="custID" value="">
				
				<?php if($Customers != ''): foreach($Customers as $Customer): if($Customer['cdefault'] == '1'): $isSelect = 'selected'; else: $isSelect = 'select'; endif; ?>
				<div id="scn<?php echo $Customer['custID']; ?>" class="bar-info">			
					<div class="<?php echo $isSelect; ?> select-name" onclick="Select(this)"><?php echo $Customer['sname']; ?></div>
					
					<span class="custID" id="<?php echo $isSelect; ?>custID" style="display:none;"><?php echo $Customer['custID']; ?></span>
					
					<span class="name" id="<?php echo $isSelect; ?>name"><?php echo $Customer['sname']; ?></span>
					<span class="address" id="<?php echo $isSelect; ?>address"><?php echo $Customer['address']; ?></span>
					<span class="phone" id="<?php echo $isSelect; ?>phone"><?php echo $Customer['mobile']; ?></span>
					
				<?php if($Customer['cdefault'] == '1'): ?>
				
					<span class="default-address">默认地址</span>
					<a class="edit" href="javascript:ConsigneeOper('<?php echo $Customer['custID']; ?>','edit')">编辑</a>
				</div>
				
				<?php else: ?>
					<a class="delete" href="javascript:ConsigneeOper('<?php echo $Customer['custID']; ?>','delete')">删除</a>
					<a class="edit" href="javascript:ConsigneeOper('<?php echo $Customer['custID']; ?>','edit')">编辑</a>
					<a class="set-default" href="javascript:ConsigneeOper('<?php echo $Customer['custID']; ?>','default')">设为默认地址</a>
				</div>
				<?php endif; endforeach; endif; ?>
			</div>
			<div class="order-bar">
				<div class="bar-title">
					<span>订购人信息</span>
				</div>
				<div class="bar-info">
				<?php if($member['mname'] == ''): ?>
					<input id="buy-name" type="text" placeholder="您的姓名" >
				<?php else: ?>	
					<input id="buy-name" type="text" value="<?php echo $member['mname']; ?>">
				<?php endif; if($member['mobile'] == ''): ?>
					<input id="buy-phone" type="text" placeholder="手机号码或电话">
				<?php else: ?>	
					<input id="buy-phone" type="text" value="<?php echo $member['mobile']; ?>">
				<?php endif; ?>
					<input id="buy-email" class="disabled" type="text" value="<?php echo $member['email']; ?>" disabled="disabled" name="buy-email">
					<button id="add-buyer" onclick="AddBuyer()">确定</button>
					
				</div>
			</div>
			<div class="order-bar">
				<div class="bar-title">
					<span class="deliver-time">配送日期</span>
					<span>配送时段</span>
				</div>
				<div class="bar-info">
					<input name="date" class="date" type="date">
					<input type="hidden" name="time" value="不限">
					<div class="selected time">不限</div>
					<div class="select time">上午</div>
					<div class="select time">下午</div>
					<div class="select time">晚上</div>
					<div class="select time">定时</div>
				</div>
			</div>
			<div class="order-bar">
				<div class="bar-title">
					<span>贺卡留言+署名</span>
				</div>
				<div class="order-bar">
					<span>最多200字，您还可以输入<span class="type-word">200</span>字。（仅支持中文，英文）</span><br>
					<textarea name="message" id="message" cols="50" rows="5" placeholder="贺卡留言+署名"></textarea>
					<div class="send-word">
						<div class="for-who who-selected">送恋人</div>
						<div class="for-who">送朋友</div>
						<div class="for-who">送长辈</div>
						<div class="words">
							<span class="word-select">1.我多么希望，有一个门口，早晨，阳光照在草上，我们站着，扶着自己的门扇，门很低，但太阳是明亮的。草在结它的种子，风在摇它的叶子，我们站着，不说话，就十分美好。</span>
							<span class="word-select">2.爱你是我一生无悔的决定，漫天星星都是我注视你的眼睛。无论结局如何，我都知道：此生最爱是你！</span>
							<span class="word-select">3.我想和你虚度时光，比如低头看鱼，比如把茶杯留在桌子上离开，浪费它们好看的阴影，我还想连落日一起浪费，比如散步，一直消磨到星光满天……</span>
							<span class="word-select">4.有些情感，无需多么华美，只是简单的遇见，简单的想念，哪怕它只是简单到：拉着你的手，迎着风走！</span>
							<span class="word-select">5.遇到你我感到很幸福，但是我不能成为世界上最幸福的人，因为我们在一起，我要让你成为世界上最幸福的人。</span>
						</div>
						<div class="words">
							<span class="word-select">1.一切的不顺心都是纸老虎！希望你开心！</span>
							<span class="word-select">2.这些日子你过得还好吗？也许忙碌改变了我们的生活，但我永远珍惜我们的情谊。</span></span>
							<span class="word-select">3.有些情感，无需多么华美，只是简单的遇见，简单的想念，哪怕它只是简单到：拉着你的手，迎着风走！</span>
							<span class="word-select">4.不求同年同月同日生，但求同年同月同日疯</span>
							<span class="word-select">5.无私无邪无猜无疑的友情无价，你是我买不到的奢华</span>
						</div>
						<div class="words">
							<span class="word-select">1.亲爱的妈妈：您曾用您坚实的臂弯为我撑起一片蓝天；而今，我也要用我日益丰满的羽翼为您遮挡风雨。妈妈，我永远爱您！生日快乐！祝我的美女妈妈越来越青春，身体健康，未来的我可以每个假期带你出去纵横~</span>
							<span class="word-select">2.妈妈，我是您身边的一只备受关怀的小鸟，今天为您衔来了一束芬芳的鲜花。</span>
							<span class="word-select">3.引一缕清风，为妈妈带去轻松；采一缕阳光，为妈妈送去芬芳；掬一捧清水，为妈妈消去疲惫；送一束鲜花，为妈妈奉上祝福。祝妈妈生日快乐！</span>
							<span class="word-select">4.不想时间过得那么快，因为我想有再多一点时间回家陪着你。不要觉得自己老了，在别人眼里，你还只是我姐呢。生日快乐，妈，我爱你！</span>
							<span class="word-select">5.父爱如山，父爱无言，您总是微笑着担起了整个家庭。在我心中，您是全天下最好的爸爸。</span>
						</div>
					</div><br>
				</div>
				
			</div>
			<div class="order-bar">
				<div class="bar-title">
					<span>支付方式</span>
				</div>
				<div class="bar-info">
					<input type="hidden" name="pay-with" value="网上支付">
					<div class="selected time">网上支付</div>
					<div class="select time">礼品卡支付</div>
					<div class="select time">货到付款</div>
				</div>
			</div>
		</div>
		<div class="edit-order">
			<div class="order-info">
				<div class="info-bar">
					<span>确认订单信息</span>
				</div>
				<?php $total = '0'; $sum = '0'; foreach($vcart as $cart): $total = $total + $cart['yourprice'] * $cart['num']; $sum = $sum + $cart['num']; ?>
				
				<div class="order-bar">
					<img class="flower-pic" src="/flowerTP/public/static/picture/<?php echo $cart['pictures']; ?>" alt="鲜花图片">
					<div class="flower-desc">
					<a href="<?php echo url('index/flowerDetail'); ?>?flowerID=<?php echo $cart['flowerID']; ?>"><?php echo $cart['fname']; ?></a>						
						<span class="flower-price"><?php echo $cart['yourprice']; ?></span>
						<span class="num">x <?php echo $cart['num']; ?></span>
					</div>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
		
		
		<div class="submit-bar">
			<span><?php echo $sum; ?>件商品，总金额：￥<?php echo $total; ?>元</span><br>
			<span>配送费：￥0元</span><br><br>
			<span>提交订单应付总额：￥<span class="total-price"><?php echo $total; ?></span>元</span><br>
			<button id="submit" class="submit">提交订单</button><br><br>
			<span id="send-to">配送至：</span><br>
			<span id="send-for">收货人：</span><br>
		</div>

		<div id="add-panel">
			<div class="title-bar">
				<span class="title">添加联系人</span>
				<span class="close-panel">&times;</span>
			</div>
			<div class="edit-panel">
				<label for="addName">姓名：</label> 
				<input id="addName" type="text" name="addName"><br>
				<label for="addPhone">电话：</label>
				<input id="addPhone" type="number" name="addPhone"><br>
				<label for="addProvince">省份：</label>
				<input id="addProvince" type="text" name="addProvince"><br>
				<label for="addCity">城市：</label>
				<input id="addCity" type="text" name="addCity"><br>
				<label for="addAddr">详细地址：</label>
				<input id="addAddr" type="text" name="addAddr">
			</div>
			<button id="add-btn" class="save" onclick="javascript:SaveConsignee('member','add')">保存</button>
			<button id="edit-btn" class="save">保存</button>
		</div>
			
		</div>

	<div id="footer">
Copyright © 2016, flowersforjx.com, All Rights Reserved 粤华师备 20132003040号 粤ICP备 123456号
</div>

</body>
</html>