<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:78:"C:\Software\AppServ\www\flowerTP/application/index\view\register\register.html";i:1592965019;s:24:"./public/common/top.html";i:1592887945;s:27:"./public/common/bottom.html";i:1592887945;}*/ ?>
﻿<meta charset="utf-8">
<center>
<table width=999px border=0>
<tr>
<td rowspan=2><img src="/flowerTP/public/static/image/logo.jpg" style="width:216px; height:68px"> </td>

<td style="font-size:x-small;">

欢迎光临鲜花礼品网</td>
<td style="background:url('/flowerTP/public/static/image/topxmenubg.jpg'); font-size:x-small;text-align:center;">
<a href="member.php" style="text-decoration:none;">我的帐户</a>|
<a href="<?php echo url('order/showorder'); ?>" style="text-decoration:none;">我的订单</a>|
<a href="<?php echo url('cart/cart'); ?>" style="text-decoration:none;">购物车</a>|
</td>
</tr>
<tr>
<td><a href="<?php echo url('login/login'); ?>" style="font-size:x-small;text-decoration:none;">登录</a>&nbsp;&nbsp;
<a href="<?php echo url('register/register'); ?>" style="font-size:x-small;text-decoration:none;">注册</a>&nbsp;&nbsp;
<a href="<?php echo url('admin/adminlogin/login'); ?>" style="font-size:x-small;text-decoration:none;">后台登录</a>&nbsp;&nbsp;</td>
<td style="text-align:right;"><img src="/flowerTP/public/static/image/ttel.jpg"></td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/bg-navbox.png'); font-size: small;text-align:center; width:999px;height:40px">
 <span style=" color:White;"> |</span> &nbsp; &nbsp; &nbsp;
    <a href="<?php echo url('index/index'); ?>" style="text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体"> 主页</span></a>
    &nbsp;&nbsp;&nbsp; <span style=" color:White;"> |</span> &nbsp;&nbsp;&nbsp;
    <a href="<?php echo url('index/showflower'); ?>"  style=" text-decoration:none;"><span style=" color:White; font-weight:bold; font-size:medium; font-family:宋体">鲜花</span></a>
     &nbsp; &nbsp; &nbsp; <span style=" color:White;"> |</span>&nbsp;&nbsp;&nbsp;
</td>
</tr>
<tr><td colspan=3 style="background:url('/flowerTP/public/static/image/search_bg.jpg'); font-size: small;text-align:center; width:999px;height:35px">
<span style="font-weight:bold; font-size:x-small; font-family:宋体">
</span>
</td>
</tr>
</table></center>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<script type="text/javascript"
	src="/flowerTP/public/static/js/jquery-1.4.2.js"></script>
	
</head>
<body>
<meta charset="utf-8">
<br><br><center>
<form action="<?php echo url('register/doRegister'); ?>" method="post" n="f">
<table style="width:480px; border-width:3px; border-style:dotted;">
<tr><td colspan=2 style="text-align:center;height:60px;">
注册新用户--填写注册信息，输入用户名和密码</td></tr>
<tr>
 <td style="text-align:right;height:30px;">E-mail地址：</td>
<td align=left><input type=text name="email" value="a@163.com" />
<span></span></td>
</tr>

<tr>
<td style="text-align:right;height:30px;">密码：</td>
<td align=left><input type="password" name="passw1" />
<span></span></td>
</tr>
<tr>
<td style="text-align:right;height:30px;">确认密码：</td>
<td align=left><input type="password" name="passw2" />
<span></span></td>
</tr>

<tr><td colspan="2" style="text-align:center;height:60px;">
<input type=submit name=s value="注册">
</td></tr>
</table>
</form>
<div id="footer">
Copyright © 2016, flowersforjx.com, All Rights Reserved 粤华师备 20132003040号 粤ICP备 123456号
</div>
</center>
</body>
</html>